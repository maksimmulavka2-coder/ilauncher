plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.ilauncher"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.ilauncher"
        minSdk = 26
        targetSdk = 34
        versionCode = 5
        versionName = "2.3"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.viewpager:viewpager:1.0.0")
}
