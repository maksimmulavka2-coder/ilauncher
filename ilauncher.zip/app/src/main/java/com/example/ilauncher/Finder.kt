package com.example.ilauncher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.text.TextUtils
import android.text.format.Formatter
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.*
import androidx.core.content.FileProvider
import androidx.core.widget.doOnTextChanged
import java.io.File
import java.util.Date
import java.util.concurrent.Executors

// Original dock icon for the file manager: blue tile with a white folder.
internal class FinderIcon : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun draw(c: Canvas) {
        val b = bounds
        val l = b.left.toFloat(); val t = b.top.toFloat(); val w = b.width().toFloat()
        p.shader = LinearGradient(0f, t, 0f, t + w, 0xFF64D2FF.toInt(), 0xFF0A84FF.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(l, t, l + w, t + w, p)
        p.shader = null
        p.color = 0xE6FFFFFF.toInt()
        c.drawRoundRect(RectF(l + w * 0.16f, t + w * 0.26f, l + w * 0.46f, t + w * 0.42f), w * 0.04f, w * 0.04f, p)
        p.color = Color.WHITE
        c.drawRoundRect(RectF(l + w * 0.16f, t + w * 0.34f, l + w * 0.84f, t + w * 0.74f), w * 0.06f, w * 0.06f, p)
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.OPAQUE
}

internal class FinderWindow(private val act: Activity, private val onClose: () -> Unit) : LinearLayout(act) {
    private class Entry(val f: File, val dir: Boolean, val size: Long, val mtime: Long)

    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT
    private val prefs = act.getSharedPreferences("l", 0)
    private val io = Executors.newSingleThreadExecutor()
    private val thumbs = Executors.newFixedThreadPool(2)
    private val cache = object : LruCache<String, Bitmap>(6 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount / 1024
    }
    private val df = java.text.DateFormat.getDateInstance(java.text.DateFormat.MEDIUM)
    private val root: File = Environment.getExternalStorageDirectory()
    private var cwd: File = root
    private val back = ArrayList<File>()
    private val fwd = ArrayList<File>()
    private var all = listOf<Entry>()
    private var items = listOf<Entry>()
    private var clip: File? = null
    private var cut = false
    private var grid = prefs.getBoolean("f_grid", false)
    private var hidden = prefs.getBoolean("f_hidden", false)
    private var sort = prefs.getInt("f_sort", 0)
    private var query = ""
    private val searchBox = EditText(act)
    private val titleTv = TextView(act)
    private val pathTv = TextView(act)
    private val viewBtn = TextView(act)
    private val sidebar = LinearLayout(act)
    private val denied = LinearLayout(act)
    private lateinit var listView: ListView
    private lateinit var gridView: GridView
    private lateinit var listAd: Ad
    private lateinit var gridAd: Ad

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }
    private fun toast(s: String) = Toast.makeText(act, s, Toast.LENGTH_SHORT).show()
    private fun tbtn(t: String, a: (View) -> Unit) = TextView(act).apply {
        text = t; textSize = 20f; setTextColor(Color.WHITE); setPadding(dp(10), dp(2), dp(10), dp(2))
        setOnClickListener { a(it) }
    }

    init {
        orientation = LinearLayout.VERTICAL
        background = bg(0xF21E1E22.toInt(), 14)
        isClickable = true

        val bar = LinearLayout(act).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(8)) }
        val cols = intArrayOf(0xFFFF5F57.toInt(), 0xFFFFBD2E.toInt(), 0xFF28C840.toInt())
        for (i in 0 until 3) bar.addView(View(act).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(cols[i]) }
            if (i == 0) setOnClickListener { onClose() }
        }, LinearLayout.LayoutParams(dp(13), dp(13)).apply { rightMargin = dp(8) })
        titleTv.apply {
            text = "Finder"; textSize = 14f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        bar.addView(titleTv, LinearLayout.LayoutParams(0, WC, 1f))
        bar.addView(View(act), LinearLayout.LayoutParams(dp(55), 1))
        addView(bar)

        val tb = LinearLayout(act).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), 0, dp(4), dp(4)) }
        tb.addView(tbtn("\u2039") { goBack() })
        tb.addView(tbtn("\u203A") { goFwd() })
        tb.addView(tbtn("\u2191") { goUp() })
        pathTv.apply {
            textSize = 12f; setTextColor(0xAAFFFFFF.toInt()); maxLines = 1
            ellipsize = TextUtils.TruncateAt.START; setPadding(dp(6), 0, dp(6), 0)
        }
        tb.addView(pathTv, LinearLayout.LayoutParams(0, WC, 1f))
        viewBtn.apply {
            textSize = 20f; setTextColor(Color.WHITE); setPadding(dp(10), dp(2), dp(10), dp(2))
            setOnClickListener { grid = !grid; prefs.edit().putBoolean("f_grid", grid).apply(); showMode() }
        }
        tb.addView(viewBtn)
        tb.addView(tbtn("\u22EF") { moreMenu(it) })
        addView(tb)

        searchBox.apply {
            hint = "Search"; setHintTextColor(0x88FFFFFF.toInt()); setTextColor(Color.WHITE); textSize = 13f
            isSingleLine = true; background = bg(0x22FFFFFF, 8); setPadding(dp(10), dp(6), dp(10), dp(6))
            doOnTextChanged { t, _, _, _ -> query = t.toString(); applyFilter() }
        }
        addView(searchBox, LinearLayout.LayoutParams(MP, WC).apply { setMargins(dp(10), 0, dp(10), dp(6)) })

        val bodyRow = LinearLayout(act)
        sidebar.apply { orientation = LinearLayout.VERTICAL; setPadding(dp(6), dp(6), dp(6), dp(6)) }
        bodyRow.addView(ScrollView(act).apply { addView(sidebar); setBackgroundColor(0x33000000) },
            LinearLayout.LayoutParams(dp(96), MP))
        val content = FrameLayout(act)
        listAd = Ad(false)
        gridAd = Ad(true)
        listView = ListView(act).apply {
            divider = null; dividerHeight = 0; setSelector(ColorDrawable(0x22FFFFFF)); adapter = listAd
            setOnItemClickListener { _, _, p, _ -> onTap(items[p]) }
            setOnItemLongClickListener { _, _, p, _ -> ctx(items[p]); true }
        }
        gridView = GridView(act).apply {
            numColumns = 3; setSelector(ColorDrawable(0x22FFFFFF)); adapter = gridAd
            setOnItemClickListener { _, _, p, _ -> onTap(items[p]) }
            setOnItemLongClickListener { _, _, p, _ -> ctx(items[p]); true }
        }
        denied.apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(24), dp(24), dp(24), dp(24)); visibility = View.GONE }
        denied.addView(TextView(act).apply {
            text = "Finder needs access to your files."; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
        })
        denied.addView(TextView(act).apply {
            text = "Allow Access"; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
            background = bg(0xFF0A84FF.toInt(), 10); setPadding(dp(18), dp(10), dp(18), dp(10))
            setOnClickListener { requestAccess() }
        }, LinearLayout.LayoutParams(WC, WC).apply { topMargin = dp(14) })
        content.addView(listView, FrameLayout.LayoutParams(MP, MP))
        content.addView(gridView, FrameLayout.LayoutParams(MP, MP))
        content.addView(denied, FrameLayout.LayoutParams(MP, MP))
        bodyRow.addView(content, LinearLayout.LayoutParams(0, MP, 1f))
        addView(bodyRow, LinearLayout.LayoutParams(MP, 0, 1f))
        showMode()
    }

    fun shutdown() { io.shutdown(); thumbs.shutdown() }

    private fun hasAccess() =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else act.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                act.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + act.packageName)))
            } catch (e: Exception) { }
        } else act.requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE), 7)
    }

    // called every time the window is shown or the app resumes
    fun refresh() {
        grid = prefs.getBoolean("f_grid", false)
        hidden = prefs.getBoolean("f_hidden", false)
        sort = prefs.getInt("f_sort", 0)
        val ok = hasAccess()
        denied.visibility = if (ok) View.GONE else View.VISIBLE
        if (ok) { buildSidebar(); showMode(); open(cwd, false) }
        else { listView.visibility = View.GONE; gridView.visibility = View.GONE }
    }

    private fun showMode() {
        viewBtn.text = if (grid) "\u2630" else "\u25A6"
        if (denied.visibility == View.VISIBLE) return
        listView.visibility = if (grid) View.GONE else View.VISIBLE
        gridView.visibility = if (grid) View.VISIBLE else View.GONE
    }

    private fun buildSidebar() {
        sidebar.removeAllViews()
        sidebar.addView(TextView(act).apply {
            text = "FAVORITES"; textSize = 10f; setTextColor(0x88FFFFFF.toInt()); setPadding(dp(6), dp(4), 0, dp(6))
        })
        val favs = listOf(
            Triple("\uD83C\uDFE0", "Internal", root),
            Triple("\u2B07\uFE0F", "Downloads", File(root, "Download")),
            Triple("\uD83D\uDCC4", "Documents", File(root, "Documents")),
            Triple("\uD83D\uDDBC\uFE0F", "Pictures", File(root, "Pictures")),
            Triple("\uD83C\uDFB5", "Music", File(root, "Music")),
            Triple("\uD83C\uDFAC", "Movies", File(root, "Movies")),
            Triple("\uD83D\uDCF7", "Camera", File(root, "DCIM")))
        favs.forEach { (e, n, f) ->
            sidebar.addView(TextView(act).apply {
                text = "$e $n"; textSize = 12f; setTextColor(Color.WHITE); maxLines = 1
                ellipsize = TextUtils.TruncateAt.END; setPadding(dp(8), dp(8), dp(4), dp(8)); tag = f
                setOnClickListener { open(f) }
            })
        }
    }

    private fun markSidebar() {
        for (i in 0 until sidebar.childCount) {
            val c = sidebar.getChildAt(i)
            c.background = if ((c.tag as? File) == cwd) bg(0x55007AFF, 8) else null
        }
    }

    // ---- navigation ----
    private fun open(dir: File, push: Boolean = true) {
        if (push && dir != cwd) { back.add(cwd); fwd.clear() }
        cwd = dir
        titleTv.text = if (dir == root) "Internal Storage" else dir.name
        pathTv.text = dir.path.replaceFirst(root.path, "Internal Storage")
        markSidebar()
        io.execute {
            val l = (dir.listFiles() ?: emptyArray()).map {
                val d = it.isDirectory
                Entry(it, d, if (d) 0L else it.length(), it.lastModified())
            }
            act.runOnUiThread { if (cwd == dir) { all = l; applyFilter() } }
        }
    }

    private fun goBack() { if (back.isNotEmpty()) { fwd.add(cwd); open(back.removeAt(back.size - 1), false) } }
    private fun goFwd() { if (fwd.isNotEmpty()) { back.add(cwd); open(fwd.removeAt(fwd.size - 1), false) } }
    private fun goUp() { val p = cwd.parentFile; if (cwd != root && p != null) open(p) }

    private fun applyFilter() {
        val q = query.trim()
        val l = all.filter { (hidden || !it.f.name.startsWith(".")) && (q.isEmpty() || it.f.name.contains(q, true)) }
        items = when (sort) {
            1 -> l.sortedWith(compareByDescending<Entry> { it.dir }.thenByDescending { it.mtime })
            2 -> l.sortedWith(compareByDescending<Entry> { it.dir }.thenByDescending { it.size })
            else -> l.sortedWith(compareByDescending<Entry> { it.dir }.thenBy { it.f.name.lowercase() })
        }
        listAd.notifyDataSetChanged(); gridAd.notifyDataSetChanged()
    }

    // ---- menus and actions ----
    private fun moreMenu(v: View) {
        val m = PopupMenu(act, v)
        m.menu.add(0, 1, 0, "New Folder")
        if (clip != null) m.menu.add(0, 2, 1, "Paste")
        m.menu.add(0, 3, 2, if (hidden) "Hide Hidden Files" else "Show Hidden Files")
        m.menu.add(0, 4, 3, "Sort by Name")
        m.menu.add(0, 5, 4, "Sort by Date")
        m.menu.add(0, 6, 5, "Sort by Size")
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> newFolder()
                2 -> paste(cwd)
                3 -> { hidden = !hidden; prefs.edit().putBoolean("f_hidden", hidden).apply(); applyFilter() }
                4 -> setSort(0)
                5 -> setSort(1)
                else -> setSort(2)
            }
            true
        }
        m.show()
    }

    private fun setSort(i: Int) { sort = i; prefs.edit().putInt("f_sort", i).apply(); applyFilter() }

    private fun onTap(e: Entry) { if (e.dir) open(e.f) else openFile(e.f) }

    private fun mimeOf(f: File) = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"

    private fun openFile(f: File) {
        try {
            val uri = FileProvider.getUriForFile(act, act.packageName + ".files", f)
            act.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mimeOf(f))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: Exception) { toast("No app can open this file") }
    }

    private fun share(f: File) {
        try {
            val uri = FileProvider.getUriForFile(act, act.packageName + ".files", f)
            val i = Intent(Intent.ACTION_SEND).setType(mimeOf(f)).putExtra(Intent.EXTRA_STREAM, uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            act.startActivity(Intent.createChooser(i, "Share"))
        } catch (e: Exception) { toast("Can't share this file") }
    }

    private fun ctx(e: Entry) {
        val opts = ArrayList<String>()
        opts.add("Open"); opts.add("Rename"); opts.add("Copy"); opts.add("Cut")
        if (clip != null && e.dir) opts.add("Paste Into Folder")
        if (!e.dir) opts.add("Share")
        opts.add("Get Info"); opts.add("Delete")
        AlertDialog.Builder(act, AlertDialog.THEME_DEVICE_DEFAULT_DARK).setTitle(e.f.name)
            .setItems(opts.toTypedArray()) { _, w ->
                when (opts[w]) {
                    "Open" -> onTap(e)
                    "Rename" -> ask("Rename", e.f.name) { n ->
                        toast(if (e.f.renameTo(File(e.f.parentFile, n))) "Renamed" else "Failed"); open(cwd, false)
                    }
                    "Copy" -> { clip = e.f; cut = false; toast("Copied") }
                    "Cut" -> { clip = e.f; cut = true; toast("Cut") }
                    "Paste Into Folder" -> paste(e.f)
                    "Share" -> share(e.f)
                    "Get Info" -> info(e)
                    "Delete" -> confirmDelete(e)
                }
            }.show()
    }

    private fun ask(title: String, initial: String, ok: (String) -> Unit) {
        val et = EditText(act).apply { setText(initial); setTextColor(Color.WHITE); isSingleLine = true; setSelectAllOnFocus(true) }
        AlertDialog.Builder(act, AlertDialog.THEME_DEVICE_DEFAULT_DARK).setTitle(title).setView(et)
            .setPositiveButton("OK") { _, _ -> val s = et.text.toString().trim(); if (s.isNotEmpty()) ok(s) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun newFolder() = ask("New Folder", "untitled folder") { n ->
        toast(if (File(cwd, n).mkdirs()) "Created" else "Failed"); open(cwd, false)
    }

    private fun confirmDelete(e: Entry) {
        AlertDialog.Builder(act, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle("Delete \"" + e.f.name + "\"?").setMessage("This cannot be undone.")
            .setPositiveButton("Delete") { _, _ ->
                io.execute {
                    val ok = e.f.deleteRecursively()
                    act.runOnUiThread { toast(if (ok) "Deleted" else "Failed"); open(cwd, false) }
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun paste(dir: File) {
        val src = clip ?: return
        if (src.isDirectory && dir.path.startsWith(src.path)) { toast("Can't paste a folder into itself"); return }
        io.execute {
            var dest = File(dir, src.name)
            var n = 1
            while (dest.exists()) {
                val ext = if (src.extension.isEmpty()) "" else "." + src.extension
                dest = File(dir, src.nameWithoutExtension + " copy" + (if (n > 1) " $n" else "") + ext)
                n++
            }
            val ok = try {
                if (cut) (src.renameTo(dest) || (src.copyRecursively(dest) && src.deleteRecursively()))
                else src.copyRecursively(dest)
            } catch (e: Exception) { false }
            act.runOnUiThread { toast(if (ok) "Done" else "Failed"); if (ok && cut) clip = null; open(cwd, false) }
        }
    }

    private fun infoText(e: Entry, size: String) =
        "Kind: " + (if (e.dir) "Folder" else e.f.extension.uppercase().ifEmpty { "Document" } + " file") +
            "\nSize: " + size + "\nWhere: " + e.f.parent +
            "\nModified: " + java.text.DateFormat.getDateTimeInstance().format(Date(e.mtime))

    private fun info(e: Entry) {
        val d = AlertDialog.Builder(act, AlertDialog.THEME_DEVICE_DEFAULT_DARK).setTitle(e.f.name)
            .setMessage(infoText(e, if (e.dir) "calculating\u2026" else Formatter.formatShortFileSize(act, e.size)))
            .setPositiveButton("OK", null).show()
        if (e.dir) io.execute {
            val sz = e.f.walkTopDown().filter { it.isFile }.sumOf { it.length() }
            act.runOnUiThread { d.setMessage(infoText(e, Formatter.formatShortFileSize(act, sz))) }
        }
    }

    // ---- list / grid rows (recycled) ----
    private fun isImage(n: String) = n.substringAfterLast('.', "").lowercase() in setOf("jpg", "jpeg", "png", "webp", "gif", "bmp")

    private fun iconFor(e: Entry): String {
        if (e.dir) return "\uD83D\uDCC1"
        return when (e.f.extension.lowercase()) {
            "jpg", "jpeg", "png", "webp", "gif", "bmp" -> "\uD83D\uDDBC\uFE0F"
            "mp4", "mkv", "avi", "mov", "3gp", "webm" -> "\uD83C\uDFAC"
            "mp3", "wav", "flac", "m4a", "ogg", "aac" -> "\uD83C\uDFB5"
            "pdf" -> "\uD83D\uDCD5"
            "zip", "rar", "7z", "tar", "gz" -> "\uD83D\uDDDC\uFE0F"
            "apk" -> "\uD83E\uDD16"
            else -> "\uD83D\uDCC4"
        }
    }

    private fun loadThumb(iv: ImageView, f: File) {
        val c = cache.get(f.path)
        if (c != null) { iv.setImageBitmap(c); return }
        iv.setImageDrawable(null)
        thumbs.execute {
            if (iv.tag != f.path) return@execute
            try {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(f.path, o)
                var s = 1
                while (o.outWidth / (s * 2) >= 160 && o.outHeight / (s * 2) >= 160) s *= 2
                val bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
                if (bmp != null) {
                    cache.put(f.path, bmp)
                    iv.post { if (iv.tag == f.path) iv.setImageBitmap(bmp) }
                }
            } catch (t: Throwable) { }
        }
    }

    private inner class VH(val grid: Boolean) {
        val emoji = TextView(act)
        val thumb = ImageView(act)
        val name = TextView(act)
        val sub = TextView(act)
        val root: View

        init {
            val isz = if (grid) dp(56) else dp(38)
            emoji.apply { gravity = Gravity.CENTER; textSize = if (grid) 34f else 24f }
            thumb.apply { scaleType = ImageView.ScaleType.CENTER_CROP; visibility = View.GONE }
            name.apply {
                setTextColor(Color.WHITE); maxLines = if (grid) 2 else 1; ellipsize = TextUtils.TruncateAt.END
                textSize = if (grid) 11f else 14f
            }
            sub.apply { setTextColor(0x99FFFFFF.toInt()); textSize = 11f; maxLines = 1 }
            val box = FrameLayout(act)
            box.addView(emoji, FrameLayout.LayoutParams(isz, isz))
            box.addView(thumb, FrameLayout.LayoutParams(isz, isz))
            val r = LinearLayout(act)
            if (grid) {
                r.orientation = LinearLayout.VERTICAL; r.gravity = Gravity.CENTER_HORIZONTAL
                r.setPadding(dp(4), dp(10), dp(4), dp(6))
                name.gravity = Gravity.CENTER
                r.addView(box, LinearLayout.LayoutParams(isz, isz))
                r.addView(name, LinearLayout.LayoutParams(MP, WC))
            } else {
                r.orientation = LinearLayout.HORIZONTAL; r.gravity = Gravity.CENTER_VERTICAL
                r.setPadding(dp(10), dp(6), dp(10), dp(6))
                val col = LinearLayout(act)
                col.orientation = LinearLayout.VERTICAL; col.setPadding(dp(10), 0, 0, 0)
                col.addView(name); col.addView(sub)
                r.addView(box, LinearLayout.LayoutParams(isz, isz))
                r.addView(col, LinearLayout.LayoutParams(0, WC, 1f))
            }
            root = r
        }

        fun bind(e: Entry) {
            name.text = e.f.name
            emoji.text = iconFor(e)
            val img = !e.dir && isImage(e.f.name)
            thumb.tag = e.f.path
            thumb.visibility = if (img) View.VISIBLE else View.GONE
            if (img) loadThumb(thumb, e.f)
            val date = df.format(Date(e.mtime))
            sub.text = if (e.dir) date else Formatter.formatShortFileSize(act, e.size) + " \u00B7 " + date
        }
    }

    private inner class Ad(val grid: Boolean) : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(p: Int): Any = items[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val vh: VH
            val v: View
            if (cv == null) { vh = VH(grid); v = vh.root; v.tag = vh } else { v = cv; vh = cv.tag as VH }
            vh.bind(items[p])
            return v
        }
    }
}
