package com.example.ilauncher

import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable

// Menu-bar icon for the control panel: two toggle pills.
internal class ControlIcon : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    private fun pill(c: Canvas, l: Float, top: Float, w: Float, ph: Float, dotRight: Boolean) {
        p.style = Paint.Style.STROKE; p.strokeWidth = ph * 0.2f
        c.drawRoundRect(RectF(l + w * 0.1f, top, l + w * 0.9f, top + ph), ph / 2, ph / 2, p)
        p.style = Paint.Style.FILL
        val cx = if (dotRight) l + w * 0.9f - ph / 2 else l + w * 0.1f + ph / 2
        c.drawCircle(cx, top + ph / 2, ph * 0.26f, p)
    }

    override fun draw(c: Canvas) {
        val b = bounds
        val l = b.left.toFloat(); val t = b.top.toFloat()
        val w = b.width().toFloat(); val h = b.height().toFloat()
        val ph = h * 0.34f
        pill(c, l, t + h * 0.12f, w, ph, false)
        pill(c, l, t + h * 0.54f, w, ph, true)
    }

    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}
