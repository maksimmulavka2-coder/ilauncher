package com.example.ilauncher

import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

// Original cloud logo used in the menu bar and in "About".
internal class CloudDrawable : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    override fun draw(c: Canvas) {
        val b = bounds
        val l = b.left.toFloat(); val t = b.top.toFloat()
        val w = b.width().toFloat(); val h = b.height().toFloat()
        c.drawCircle(l + w * 0.30f, t + h * 0.62f, w * 0.20f, p)
        c.drawCircle(l + w * 0.48f, t + h * 0.45f, w * 0.26f, p)
        c.drawCircle(l + w * 0.72f, t + h * 0.60f, w * 0.20f, p)
        c.drawRoundRect(RectF(l + w * 0.14f, t + h * 0.58f, l + w * 0.88f, t + h * 0.82f), h * 0.12f, h * 0.12f, p)
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}

internal interface PrefsHost {
    fun showWall(on: Boolean)
    fun applyClock()
    fun renderDock()
    fun applyWallpaper()
    fun resetDock()
    fun isHome(): Boolean
    fun close()
}

// "System Preferences": a grid of panes, each opening inside the same window.
internal class PrefsWindow(private val act: Activity, private val host: PrefsHost) : LinearLayout(act) {
    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT
    private val prefs = act.getSharedPreferences("l", 0)
    private val body = FrameLayout(act)
    private val titleTv = TextView(act)
    private val backBtn = TextView(act)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    init {
        orientation = LinearLayout.VERTICAL
        background = bg(0xF21E1E22.toInt(), 14)
        isClickable = true
        val bar = LinearLayout(act).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10)) }
        val cols = intArrayOf(0xFFFF5F57.toInt(), 0xFFFFBD2E.toInt(), 0xFF28C840.toInt())
        for (i in 0 until 3) bar.addView(View(act).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(cols[i]) }
            if (i == 0) setOnClickListener { host.close() }
        }, LinearLayout.LayoutParams(dp(13), dp(13)).apply { rightMargin = dp(8) })
        backBtn.apply {
            text = "\u2039 All"; textSize = 14f; setTextColor(0xFF0A84FF.toInt()); setPadding(dp(8), 0, dp(8), 0)
            setOnClickListener { showHome() }
        }
        bar.addView(backBtn)
        titleTv.apply { textSize = 14f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER }
        bar.addView(titleTv, LinearLayout.LayoutParams(0, WC, 1f))
        bar.addView(View(act), LinearLayout.LayoutParams(dp(40), 1))
        addView(bar)
        addView(View(act).apply { setBackgroundColor(0x22FFFFFF) }, LinearLayout.LayoutParams(MP, 1))
        addView(body, LinearLayout.LayoutParams(MP, 0, 1f))
        showHome()
    }

    fun showHome() {
        titleTv.text = "System Preferences"
        backBtn.visibility = View.INVISIBLE
        body.removeAllViews()
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(18), dp(12), dp(12)) }
        val panes = listOf(
            Triple("General", "\u2699\uFE0F", 0xFF8E8E93.toInt()),
            Triple("Wallpaper", "\uD83D\uDDBC\uFE0F", 0xFF0A84FF.toInt()),
            Triple("Dock", "\uD83D\uDD32", 0xFF30B0C7.toInt()),
            Triple("Finder", "\uD83D\uDCC1", 0xFF5E5CE6.toInt()),
            Triple("Launcher", "\uD83C\uDFE0", 0xFFFF9F0A.toInt()),
            Triple("About", "\u2139\uFE0F", 0xFF636366.toInt()))
        for (r in 0 until 2) {
            val row = LinearLayout(act)
            for (c in 0 until 3) {
                val (name, emoji, color) = panes[r * 3 + c]
                val cell = LinearLayout(act).apply {
                    orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                    setOnClickListener { showPane(name) }
                }
                cell.addView(TextView(act).apply { text = emoji; textSize = 26f; gravity = Gravity.CENTER; background = bg(color, 13) },
                    LinearLayout.LayoutParams(dp(54), dp(54)))
                cell.addView(TextView(act).apply {
                    text = name; textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0)
                })
                row.addView(cell, LinearLayout.LayoutParams(0, WC, 1f))
            }
            col.addView(row, LinearLayout.LayoutParams(MP, WC).apply { bottomMargin = dp(18) })
        }
        body.addView(ScrollView(act).apply { addView(col) })
    }

    fun showPaneByName(name: String) = showPane(name)

    private fun showPane(name: String) {
        titleTv.text = name
        backBtn.visibility = View.VISIBLE
        body.removeAllViews()
        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), dp(16)) }
        when (name) {
            "General" -> {
                box.addView(sw("24-hour clock", "h24", true) { host.applyClock() })
            }
            "Wallpaper" -> {
                box.addView(ImageView(act).apply {
                    setImageBitmap(BitmapFactory.decodeResource(act.resources, R.drawable.wallpaper,
                        BitmapFactory.Options().apply { inSampleSize = 4 }))
                    scaleType = ImageView.ScaleType.CENTER_CROP
                }, LinearLayout.LayoutParams(dp(110), dp(220)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(8) })
                box.addView(sw("Built-in wallpaper", "wall", true) { host.showWall(it) })
                box.addView(btn("Apply to Home & Lock screen") { host.applyWallpaper() },
                    LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(12) })
            }
            "Dock" -> {
                box.addView(label("Size"))
                box.addView(seek(32, "dsize", 16) { host.renderDock() })
                box.addView(label("Magnification (left = off)"))
                box.addView(seek(100, "mag", 75) { })
                box.addView(btn("Reset Dock") { host.resetDock() },
                    LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(18) })
            }
            "Finder" -> {
                box.addView(sw("Show hidden files", "f_hidden", false) { })
                box.addView(sw("Icon view by default", "f_grid", false) { })
                box.addView(label("Sort by"))
                val rg = RadioGroup(act)
                listOf("Name", "Date Modified", "Size").forEachIndexed { i, n ->
                    rg.addView(RadioButton(act).apply { text = n; id = 100 + i; setTextColor(Color.WHITE) })
                }
                rg.check(100 + prefs.getInt("f_sort", 0))
                rg.setOnCheckedChangeListener { _, id -> prefs.edit().putInt("f_sort", id - 100).apply() }
                box.addView(rg)
            }
            "Launcher" -> {
                box.addView(TextView(act).apply {
                    text = if (host.isHome()) "This launcher is your home screen." else "Preview mode: another launcher is your home screen."
                    textSize = 14f; setTextColor(Color.WHITE)
                })
                box.addView(btn("Set as default launcher") { go(Intent(Settings.ACTION_HOME_SETTINGS)) },
                    LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(16) })
                box.addView(TextView(act).apply {
                    text = "To go back to your old launcher: Android Settings \u2192 Apps \u2192 Default apps \u2192 Home app."
                    textSize = 12f; setTextColor(0x99FFFFFF.toInt()); setPadding(0, dp(12), 0, 0)
                })
            }
            else -> about(box)
        }
        body.addView(ScrollView(act).apply { addView(box) })
    }

    // ---- About This Launcher ----
    private fun about(box: LinearLayout) {
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.addView(ImageView(act).apply {
            setImageDrawable(CloudDrawable()); setPadding(dp(10), dp(10), dp(10), dp(10))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF1AA7EC.toInt(), 0xFFFF4D4D.toInt(), 0xFFB5179E.toInt())).apply { cornerRadius = dp(18).toFloat() }
        }, LinearLayout.LayoutParams(dp(76), dp(76)).apply { topMargin = dp(8) })
        box.addView(TextView(act).apply {
            text = "Launcher"; textSize = 26f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(10), 0, 0)
        })
        val ver = try { act.packageManager.getPackageInfo(act.packageName, 0).versionName } catch (e: Exception) { "1.0" }
        box.addView(TextView(act).apply { text = "Version $ver"; textSize = 13f; setTextColor(0x99FFFFFF.toInt()) })
        val rows = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(18), 0, dp(8)) }
        val maker = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        rows.addView(infoRow("Device", maker + " " + Build.MODEL))
        rows.addView(infoRow("Android", Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")"))
        rows.addView(infoRow("Processor", Build.HARDWARE))
        try {
            val mi = ActivityManager.MemoryInfo()
            (act.getSystemService(Activity.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
            rows.addView(infoRow("Memory", "%.1f GB".format(mi.totalMem / 1073741824.0)))
        } catch (e: Exception) { }
        try {
            val st = StatFs(Environment.getDataDirectory().path)
            rows.addView(infoRow("Storage", "%.0f GB available of %.0f GB".format(
                st.availableBytes / 1073741824.0, st.totalBytes / 1073741824.0)))
        } catch (e: Exception) { }
        val dm = act.resources.displayMetrics
        rows.addView(infoRow("Display", dm.widthPixels.toString() + " \u00D7 " + dm.heightPixels))
        box.addView(rows, LinearLayout.LayoutParams(MP, WC))
        box.addView(btn("More Info\u2026") { go(Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)) },
            LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(6) })
        box.addView(btn("Software Update\u2026") { go(Intent("android.settings.SYSTEM_UPDATE_SETTINGS")) },
            LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(8) })
    }

    private fun infoRow(k: String, v: String) = LinearLayout(act).apply {
        setPadding(0, dp(5), 0, dp(5))
        addView(TextView(act).apply { text = k; textSize = 13f; setTextColor(0x99FFFFFF.toInt()); gravity = Gravity.END },
            LinearLayout.LayoutParams(0, WC, 0.4f))
        addView(TextView(act).apply { text = v; textSize = 13f; setTextColor(Color.WHITE); setPadding(dp(12), 0, 0, 0) },
            LinearLayout.LayoutParams(0, WC, 0.6f))
    }

    // ---- small widgets ----
    private fun go(i: Intent) { try { act.startActivity(i) } catch (e: Exception) { } }

    private fun label(t: String) = TextView(act).apply {
        text = t; textSize = 13f; setTextColor(0xCCFFFFFF.toInt()); setPadding(0, dp(14), 0, dp(2))
    }

    private fun sw(t: String, key: String, def: Boolean, on: (Boolean) -> Unit) = Switch(act).apply {
        text = t; setTextColor(Color.WHITE); setPadding(0, dp(8), 0, dp(8))
        isChecked = prefs.getBoolean(key, def)
        setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(key, c).apply(); on(c) }
    }

    private fun seek(top: Int, key: String, def: Int, on: () -> Unit) = SeekBar(act).apply {
        max = top; progress = prefs.getInt(key, def)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) { prefs.edit().putInt(key, p).apply(); on() }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    private fun btn(t: String, a: () -> Unit) = TextView(act).apply {
        text = t; textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        background = bg(0x44FFFFFF, 10); setPadding(dp(12), dp(12), dp(12), dp(12)); setOnClickListener { a() }
    }
}
