package com.example.ilauncher

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.graphics.BitmapFactory
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.TextUtils
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.core.widget.doOnTextChanged
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.min

private class PageAdapter(val pages: List<View>) : PagerAdapter() {
    override fun getCount() = pages.size
    override fun isViewFromObject(v: View, o: Any) = v === o
    override fun instantiateItem(c: ViewGroup, p: Int): Any { c.addView(pages[p]); return pages[p] }
    override fun destroyItem(c: ViewGroup, p: Int, o: Any) { c.removeView(o as View) }
}

private class LaunchpadIcon : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cols = intArrayOf(0xFFFF5F57.toInt(), 0xFFFFBD2E.toInt(), 0xFF28C840.toInt(),
        0xFF0A84FF.toInt(), 0xFFBF5AF2.toInt(), 0xFFFF375F.toInt(),
        0xFF64D2FF.toInt(), 0xFFFF9F0A.toInt(), 0xFF30D158.toInt())
    override fun draw(c: Canvas) {
        val b = bounds
        val w = b.width().toFloat()
        p.shader = LinearGradient(0f, 0f, 0f, w, 0xFFEDEDF2.toInt(), 0xFF9A9AA6.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat(), p)
        p.shader = null
        for (i in 0 until 9) {
            p.color = cols[i]
            c.drawCircle(b.left + w * (0.25f + 0.25f * (i % 3)), b.top + w * (0.25f + 0.25f * (i / 3)), w * 0.09f, p)
        }
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.OPAQUE
}

class MainActivity : Activity() {
    private class App(val label: String, val pkg: String, val intent: Intent?, val icon: Drawable)

    private val LP = "__launchpad__"
    private val COLS = 4
    private val ROWS = 5
    private val MAX_DOCK = 6
    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT
    private var apps = listOf<App>()
    private var matches = listOf<App>()
    private var dockItems = listOf<App>()
    private lateinit var main: LinearLayout
    private lateinit var menubar: LinearLayout
    private lateinit var dock: LinearLayout
    private lateinit var tip: TextView
    private lateinit var panel: LinearLayout
    private lateinit var launchpad: LinearLayout
    private lateinit var pager: ViewPager
    private lateinit var dots: LinearLayout
    private lateinit var searchInput: EditText
    private lateinit var resultsScroll: ScrollView
    private lateinit var results: LinearLayout
    private lateinit var gd: GestureDetector
    private val prefs by lazy { getSharedPreferences("l", 0) }
    private var downX = 0f
    private var downT = 0L
    private var moved = false

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { loadApps(); render() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }
    private fun go(i: Intent) { try { startActivity(i) } catch (e: Exception) { } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        loadApps()
        if (!prefs.getBoolean("wp", false)) {
            prefs.edit().putBoolean("wp", true).apply()
            Thread {
                try {
                    WallpaperManager.getInstance(this)
                        .setBitmap(BitmapFactory.decodeResource(resources, R.drawable.wallpaper))
                } catch (e: Exception) { }
            }.start()
        }
        val frame = FrameLayout(this)
        frame.clipChildren = false

        main = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; clipChildren = false }

        // ---- menu bar ----
        menubar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0x66000000)
        }
        menubar.addView(TextView(this).apply {
            text = "Launcher"; textSize = 13f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        })
        menubar.addView(TextView(this).apply {
            text = "   File   Edit   View   Window   Help"; textSize = 13f; setTextColor(0xBBFFFFFF.toInt())
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, WC, 1f))
        menubar.addView(TextClock(this).apply {
            format12Hour = "EEE  HH:mm"; format24Hour = "EEE  HH:mm"
            textSize = 13f; setTextColor(Color.WHITE)
        })
        menubar.addView(TextView(this).apply {
            text = "  \u2699"; textSize = 16f; setTextColor(Color.WHITE)
            setOnClickListener {
                panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }
        })
        main.addView(menubar, LinearLayout.LayoutParams(MP, dp(28)))

        // empty desktop: wallpaper shows through
        main.addView(View(this), LinearLayout.LayoutParams(MP, 0, 1f))

        // ---- dock ----
        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM; clipChildren = false
            setPadding(dp(8), dp(8), dp(8), dp(8)); background = bg(0x66FFFFFF, 20)
        }
        main.addView(dock, LinearLayout.LayoutParams(WC, WC).apply {
            gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(10)
        })
        dock.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX = e.x; downT = e.eventTime; moved = false; magnify(e.x) }
                MotionEvent.ACTION_MOVE -> { if (abs(e.x - downX) > dp(10)) moved = true; magnify(e.x) }
                MotionEvent.ACTION_UP -> {
                    val i = indexAt(e.x)
                    resetDock()
                    if (!moved && i >= 0) {
                        if (e.eventTime - downT > 500) menu(dockItems[i]) else launch(dockItems[i])
                    }
                }
                MotionEvent.ACTION_CANCEL -> resetDock()
            }
            true
        }
        frame.addView(main, FrameLayout.LayoutParams(MP, MP))

        // ---- launchpad ----
        launchpad = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xE60C0F16.toInt())
            setPadding(dp(16), dp(16), dp(16), dp(8)); visibility = View.GONE; isClickable = true
        }
        searchInput = EditText(this).apply {
            hint = "\uD83D\uDD0D Search"; setHintTextColor(0x99FFFFFF.toInt()); setTextColor(Color.WHITE)
            isSingleLine = true; gravity = Gravity.CENTER; textSize = 14f
            background = bg(0x33FFFFFF, 10); setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        launchpad.addView(searchInput, LinearLayout.LayoutParams(dp(240), WC).apply {
            gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(8); bottomMargin = dp(12)
        })
        val body = FrameLayout(this)
        pager = ViewPager(this)
        pager.addOnPageChangeListener(object : ViewPager.SimpleOnPageChangeListener() {
            override fun onPageSelected(p: Int) { updateDots(p) }
        })
        body.addView(pager, FrameLayout.LayoutParams(MP, MP))
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        resultsScroll = ScrollView(this).apply { addView(results); visibility = View.GONE }
        body.addView(resultsScroll, FrameLayout.LayoutParams(MP, MP))
        launchpad.addView(body, LinearLayout.LayoutParams(MP, 0, 1f))
        dots = LinearLayout(this).apply { gravity = Gravity.CENTER }
        launchpad.addView(dots, LinearLayout.LayoutParams(MP, dp(20)))
        searchInput.doOnTextChanged { t, _, _, _ -> filter(t.toString()) }
        searchInput.setOnEditorActionListener { _, _, _ -> matches.firstOrNull()?.let { launch(it) }; true }
        frame.addView(launchpad, FrameLayout.LayoutParams(MP, MP))

        // ---- control panel ----
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bg(0xEE2A2A30.toInt(), 16)
            setPadding(dp(10), dp(10), dp(10), dp(6)); visibility = View.GONE
        }
        listOf("Wi-Fi" to Settings.ACTION_WIFI_SETTINGS, "Bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS,
            "Display" to Settings.ACTION_DISPLAY_SETTINGS, "Sound" to Settings.ACTION_SOUND_SETTINGS,
            "Battery" to Settings.ACTION_BATTERY_SAVER_SETTINGS).forEach { (name, act) ->
            panel.addView(TextView(this).apply {
                text = name; textSize = 15f; setTextColor(Color.WHITE); background = bg(0x33FFFFFF, 10)
                setPadding(dp(14), dp(10), dp(14), dp(10))
                setOnClickListener { panel.visibility = View.GONE; go(Intent(act)) }
            }, LinearLayout.LayoutParams(MP, WC).apply { bottomMargin = dp(4) })
        }
        frame.addView(panel, FrameLayout.LayoutParams(dp(200), WC).apply {
            gravity = Gravity.TOP or Gravity.END; setMargins(0, dp(32), dp(8), 0)
        })

        // ---- dock tooltip ----
        tip = TextView(this).apply {
            textSize = 12f; setTextColor(Color.WHITE); background = bg(0xCC333338.toInt(), 8)
            setPadding(dp(10), dp(4), dp(10), dp(4)); visibility = View.GONE
        }
        frame.addView(tip, FrameLayout.LayoutParams(WC, WC).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; bottomMargin = dp(130)
        })

        frame.setOnApplyWindowInsetsListener { v, ins ->
            val top = ins.systemWindowInsetTop
            v.setPadding(0, 0, 0, ins.systemWindowInsetBottom)
            menubar.layoutParams.height = dp(28) + top
            menubar.setPadding(dp(12), top, dp(12), 0)
            launchpad.setPadding(dp(16), top + dp(16), dp(16), dp(8))
            (panel.layoutParams as FrameLayout.LayoutParams).topMargin = dp(32) + top
            ins
        }
        setContentView(frame)

        gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 != null && launchpad.visibility != View.VISIBLE && vy < -1500 &&
                    e1.y - e2.y > dp(100) && abs(vx) < abs(vy) && e1.y < main.height - dp(110)) openLaunchpad()
                return false
            }
        })

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED); addDataScheme("package")
        }
        registerReceiver(pkgReceiver, f)
        render()
    }

    override fun dispatchTouchEvent(e: MotionEvent): Boolean { gd.onTouchEvent(e); return super.dispatchTouchEvent(e) }
    override fun onDestroy() { unregisterReceiver(pkgReceiver); super.onDestroy() }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); closeLaunchpad(); panel.visibility = View.GONE }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (launchpad.visibility == View.VISIBLE) closeLaunchpad() else panel.visibility = View.GONE }

    // ---- data ----
    private fun loadApps() {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { r ->
                App(r.loadLabel(pm).toString(), r.activityInfo.packageName,
                    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                        .setClassName(r.activityInfo.packageName, r.activityInfo.name)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    r.loadIcon(pm))
            }
            .sortedBy { it.label.lowercase() }
    }

    private fun defaultDock(): List<String> {
        val intents = listOf(
            Intent(Intent.ACTION_DIAL), Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE), Intent(Settings.ACTION_SETTINGS))
        return intents.mapNotNull {
            packageManager.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        }.distinct().filter { p -> apps.any { it.pkg == p } }
    }

    private fun dockPkgs(): List<String> =
        prefs.getString("dock", null)?.split(",")?.filter { it.isNotEmpty() } ?: defaultDock()

    // ---- UI building ----
    private fun render() {
        val d = dockPkgs()
        dockItems = listOf(App("Launchpad", LP, null, LaunchpadIcon())) + d.mapNotNull { p -> apps.find { it.pkg == p } }
        val slot = min(dp(56), (resources.displayMetrics.widthPixels - dp(40)) / dockItems.size)
        dock.removeAllViews()
        dockItems.forEach { a ->
            dock.addView(roundIcon(a, 0), LinearLayout.LayoutParams(slot - dp(8), slot - dp(8)).apply {
                setMargins(dp(4), 0, dp(4), 0)
            })
        }
        val pages = apps.chunked(COLS * ROWS).ifEmpty { listOf(emptyList<App>()) }.map { page(it) }
        val cur = pager.currentItem
        pager.adapter = PageAdapter(pages)
        pager.currentItem = cur.coerceAtMost(pages.size - 1)
        dots.removeAllViews()
        pages.indices.forEach { _ ->
            dots.addView(View(this), LinearLayout.LayoutParams(dp(7), dp(7)).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        updateDots(pager.currentItem)
    }

    private fun updateDots(sel: Int) {
        for (i in 0 until dots.childCount)
            dots.getChildAt(i).background = bg(if (i == sel) 0xFFFFFFFF.toInt() else 0x66FFFFFF, 4)
    }

    private fun page(items: List<App>): View {
        val p = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), 0, dp(8), 0) }
        for (r in 0 until ROWS) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until COLS) {
                val a = items.getOrNull(r * COLS + c)
                row.addView(if (a != null) tile(a) else View(this), LinearLayout.LayoutParams(0, MP, 1f))
            }
            p.addView(row, LinearLayout.LayoutParams(MP, 0, 1f))
        }
        return p
    }

    private fun roundIcon(a: App, size: Int) = ImageView(this).apply {
        setImageDrawable(a.icon)
        if (size > 0) layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, v.width * 0.225f) }
        }
        clipToOutline = true
    }

    private fun tile(a: App): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        box.addView(roundIcon(a, 58))
        box.addView(TextView(this).apply {
            text = a.label; setTextColor(Color.WHITE); textSize = 11f; maxLines = 1
            ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
            setShadowLayer(4f, 0f, 1f, Color.BLACK); setPadding(dp(2), dp(4), dp(2), 0)
        })
        box.setOnClickListener { launch(a) }
        box.setOnLongClickListener { menu(a); true }
        return box
    }

    // ---- dock magnification ----
    private fun magnify(x: Float) {
        val n = dock.childCount
        if (n == 0) return
        val s = FloatArray(n)
        val e = FloatArray(n)
        var total = 0f
        val sigma = dp(55).toFloat()
        for (i in 0 until n) {
            val c = dock.getChildAt(i)
            val d = (x - (c.left + c.width / 2f)) / sigma
            s[i] = 1f + 0.9f * exp(-d * d)
            e[i] = (s[i] - 1f) * (c.width + dp(8))
            total += e[i]
        }
        var acc = 0f
        var best = 0
        var bestS = 0f
        for (i in 0 until n) {
            val c = dock.getChildAt(i)
            c.pivotX = c.width / 2f
            c.pivotY = c.height.toFloat()
            c.scaleX = s[i]; c.scaleY = s[i]
            c.translationX = acc + e[i] / 2f - total / 2f
            acc += e[i]
            if (s[i] > bestS) { bestS = s[i]; best = i }
        }
        val c = dock.getChildAt(best)
        tip.text = dockItems[best].label
        tip.visibility = View.VISIBLE
        tip.translationX = dock.x + c.left + c.width / 2f + c.translationX - main.width / 2f
    }

    private fun resetDock() {
        tip.visibility = View.GONE
        for (i in 0 until dock.childCount)
            dock.getChildAt(i).animate().scaleX(1f).scaleY(1f).translationX(0f).setDuration(180).start()
    }

    private fun indexAt(x: Float): Int {
        var bi = -1
        var bd = Float.MAX_VALUE
        for (i in 0 until dock.childCount) {
            val c = dock.getChildAt(i)
            val d = abs(x - (c.left + c.width / 2f))
            if (d < bd) { bd = d; bi = i }
        }
        return bi
    }

    // ---- actions ----
    private fun launch(a: App) {
        if (a.pkg == LP) { openLaunchpad(); return }
        closeLaunchpad()
        a.intent?.let { go(it) }
    }

    private fun menu(a: App) {
        if (a.pkg == LP) return
        val d = dockPkgs().toMutableList()
        val inDock = a.pkg in d
        val items = arrayOf(if (inDock) "Remove from Dock" else "Keep in Dock", "App info", "Uninstall")
        AlertDialog.Builder(this).setTitle(a.label).setItems(items) { _, w ->
            when (w) {
                0 -> {
                    if (inDock) d.remove(a.pkg)
                    else if (d.size < MAX_DOCK) d.add(a.pkg)
                    else Toast.makeText(this, "Dock is full", Toast.LENGTH_SHORT).show()
                    prefs.edit().putString("dock", d.joinToString(",")).apply(); render()
                }
                1 -> go(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}")))
                2 -> go(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
            }
        }.show()
    }

    private fun openLaunchpad() {
        panel.visibility = View.GONE
        searchInput.setText("")
        filter("")
        pager.currentItem = 0
        launchpad.alpha = 0f; launchpad.scaleX = 1.12f; launchpad.scaleY = 1.12f
        launchpad.visibility = View.VISIBLE
        launchpad.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).start()
    }

    private fun closeLaunchpad() {
        if (launchpad.visibility != View.VISIBLE) return
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(searchInput.windowToken, 0)
        launchpad.animate().alpha(0f).scaleX(1.12f).scaleY(1.12f).setDuration(160)
            .withEndAction { launchpad.visibility = View.GONE }.start()
    }

    private fun filter(q: String) {
        results.removeAllViews()
        if (q.isBlank()) {
            matches = apps; pager.visibility = View.VISIBLE; resultsScroll.visibility = View.GONE; return
        }
        matches = apps.filter { it.label.contains(q.trim(), true) }
        pager.visibility = View.GONE; resultsScroll.visibility = View.VISIBLE
        matches.forEach { a ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(8), dp(8), dp(8)); setOnClickListener { launch(a) }
            }
            row.addView(roundIcon(a, 44))
            row.addView(TextView(this).apply {
                text = a.label; textSize = 16f; setTextColor(Color.WHITE); setPadding(dp(14), 0, 0, 0)
            })
            results.addView(row)
        }
    }
}
