package com.example.ilauncher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.TextUtils
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.core.widget.doOnTextChanged
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import java.util.Calendar
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// Pages are built lazily: only the visible page and its neighbours exist at any time.
private class PageAdapter(val n: Int, val build: (Int) -> View) : PagerAdapter() {
    override fun getCount() = n
    override fun isViewFromObject(v: View, o: Any) = v === o
    override fun instantiateItem(c: ViewGroup, p: Int): Any { val v = build(p); c.addView(v); return v }
    override fun destroyItem(c: ViewGroup, p: Int, o: Any) { c.removeView(o as View) }
}

private class LaunchpadIcon : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cols = intArrayOf(0xFFFF5F57.toInt(), 0xFFFFBD2E.toInt(), 0xFF28C840.toInt(),
        0xFF0A84FF.toInt(), 0xFFBF5AF2.toInt(), 0xFFFF375F.toInt(),
        0xFF64D2FF.toInt(), 0xFFFF9F0A.toInt(), 0xFF30D158.toInt())
    override fun draw(c: Canvas) {
        val b = bounds
        val w = b.width().toFloat()
        p.shader = LinearGradient(0f, 0f, 0f, w, 0xFFEDEDF2.toInt(), 0xFF9A9AA6.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat(), p)
        p.shader = null
        for (i in 0 until 9) {
            p.color = cols[i]
            c.drawCircle(b.left + w * (0.25f + 0.25f * (i % 3)), b.top + w * (0.25f + 0.25f * (i / 3)), w * 0.09f, p)
        }
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.OPAQUE
}

class MainActivity : Activity() {
    private class App(val label: String, val pkg: String, val intent: Intent?, val icon: Drawable)

    private val LP = "__launchpad__"
    private val FIN = "__finder__"
    private val COLS = 4
    private val ROWS = 5
    private val MAX_DOCK = 6
    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT
    private val io = Executors.newSingleThreadExecutor()
    private val lpApp by lazy { App("Launchpad", LP, null, LaunchpadIcon()) }
    private val finderApp by lazy { App("Finder", FIN, null, FinderIcon()) }
    private var apps = listOf<App>()
    private var matches = listOf<App>()
    private var dockItems = listOf<App>()
    private lateinit var main: LinearLayout
    private lateinit var wall: ImageView
    private lateinit var clockView: TextClock
    private lateinit var menubar: LinearLayout
    private lateinit var dock: LinearLayout
    private lateinit var tip: TextView
    private lateinit var panel: LinearLayout
    private lateinit var helpWin: LinearLayout
    private lateinit var frameRef: FrameLayout
    private var finder: FinderWindow? = null
    private var prefsWin: PrefsWindow? = null
    private var topInset = 0
    private lateinit var launchpad: LinearLayout
    private lateinit var pager: ViewPager
    private lateinit var dots: LinearLayout
    private lateinit var searchInput: EditText
    private lateinit var resultsScroll: ScrollView
    private lateinit var results: LinearLayout
    private lateinit var calTitle: TextView
    private lateinit var calGrid: LinearLayout
    private lateinit var wifiTile: TextView
    private lateinit var btTile: TextView
    private lateinit var apTile: TextView
    private lateinit var brightSeek: SeekBar
    private lateinit var volSeek: SeekBar
    private lateinit var gd: GestureDetector
    private val month: Calendar = Calendar.getInstance()
    private val prefs by lazy { getSharedPreferences("l", 0) }
    private var downX = 0f
    private var downT = 0L
    private var moved = false
    private var infl = 0f
    private var lastX = 0f
    private var inflAnim: ValueAnimator? = null

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { loadAppsAsync() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }
    private fun go(i: Intent) { try { startActivity(i) } catch (e: Exception) { } }
    private fun decodeWall() = BitmapFactory.decodeResource(resources, R.drawable.wallpaper,
        BitmapFactory.Options().apply { inSampleSize = 2 })

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val wallOn = prefs.getBoolean("wall", true)
        if (!wallOn) window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val frame = FrameLayout(this)
        frame.clipChildren = false
        frameRef = frame
        main = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; clipChildren = false }

        // ---- menu bar ----
        menubar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0x66000000)
        }
        menubar.addView(ImageView(this).apply {
            setImageDrawable(CloudDrawable()); setPadding(dp(3), dp(3), dp(3), dp(3))
            setOnClickListener { logoMenu(it) }
        }, LinearLayout.LayoutParams(dp(26), dp(26)))
        listOf("File", "Edit", "View", "Help").forEach { name ->
            menubar.addView(TextView(this).apply {
                text = name; textSize = 13f; setTextColor(0xDDFFFFFF.toInt()); setPadding(dp(7), dp(4), dp(7), dp(4))
                when (name) {
                    "Help" -> setOnClickListener { showHelp() }
                    "File" -> setOnClickListener { fileMenu(it) }
                }
            })
        }
        menubar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        clockView = TextClock(this).apply {
            textSize = 13f; setTextColor(Color.WHITE); setOnClickListener { togglePanel() }
        }
        applyClock()
        menubar.addView(clockView)
        menubar.addView(TextView(this).apply {
            text = "  \u2699"; textSize = 16f; setTextColor(Color.WHITE); setOnClickListener { settings() }
        })
        main.addView(menubar, LinearLayout.LayoutParams(MP, dp(28)))

        main.addView(View(this).apply {
            setOnLongClickListener { settings(); true }
            setOnClickListener { hideOverlays() }
        }, LinearLayout.LayoutParams(MP, 0, 1f))

        // ---- dock ----
        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM; clipChildren = false
            setPadding(dp(8), dp(8), dp(8), dp(8)); background = bg(0x66FFFFFF, 20)
        }
        main.addView(dock, LinearLayout.LayoutParams(WC, WC).apply {
            gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(10)
        })
        dock.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.x; downT = e.eventTime; moved = false; lastX = e.x
                    animInfl(1f, 170)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.x - downX) > dp(10)) moved = true
                    lastX = e.x; applyMag()
                }
                MotionEvent.ACTION_UP -> {
                    val i = indexAt(e.x)
                    animInfl(0f, 240)
                    if (!moved && i >= 0 && i < dockItems.size) {
                        if (e.eventTime - downT > 500) menu(dockItems[i]) else launch(dockItems[i])
                    }
                }
                MotionEvent.ACTION_CANCEL -> animInfl(0f, 240)
            }
            true
        }
        frame.addView(main, FrameLayout.LayoutParams(MP, MP))

        // ---- launchpad ----
        launchpad = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xE60C0F16.toInt())
            setPadding(dp(16), dp(16), dp(16), dp(8)); visibility = View.GONE; isClickable = true
        }
        searchInput = EditText(this).apply {
            hint = "\uD83D\uDD0D Search"; setHintTextColor(0x99FFFFFF.toInt()); setTextColor(Color.WHITE)
            isSingleLine = true; gravity = Gravity.CENTER; textSize = 14f
            background = bg(0x33FFFFFF, 10); setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        launchpad.addView(searchInput, LinearLayout.LayoutParams(dp(240), WC).apply {
            gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(8); bottomMargin = dp(12)
        })
        val body = FrameLayout(this)
        pager = ViewPager(this)
        pager.addOnPageChangeListener(object : ViewPager.SimpleOnPageChangeListener() {
            override fun onPageSelected(p: Int) { updateDots(p) }
        })
        body.addView(pager, FrameLayout.LayoutParams(MP, MP))
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        resultsScroll = ScrollView(this).apply { addView(results); visibility = View.GONE }
        body.addView(resultsScroll, FrameLayout.LayoutParams(MP, MP))
        launchpad.addView(body, LinearLayout.LayoutParams(MP, 0, 1f))
        dots = LinearLayout(this).apply { gravity = Gravity.CENTER }
        launchpad.addView(dots, LinearLayout.LayoutParams(MP, dp(20)))
        searchInput.doOnTextChanged { t, _, _, _ -> filter(t.toString()) }
        searchInput.setOnEditorActionListener { _, _, _ -> matches.firstOrNull()?.let { launch(it) }; true }
        frame.addView(launchpad, FrameLayout.LayoutParams(MP, MP))

        // ---- clock panel and help window ----
        panel = buildPanel()
        frame.addView(panel, FrameLayout.LayoutParams(min(dp(300), resources.displayMetrics.widthPixels - dp(16)), WC).apply {
            gravity = Gravity.TOP or Gravity.END; setMargins(0, dp(32), dp(8), 0)
        })
        helpWin = buildHelp()
        frame.addView(helpWin, FrameLayout.LayoutParams(
            min(dp(340), resources.displayMetrics.widthPixels - dp(24)),
            (resources.displayMetrics.heightPixels * 0.62f).toInt()).apply { gravity = Gravity.CENTER })

        // ---- dock tooltip ----
        tip = TextView(this).apply {
            textSize = 12f; setTextColor(Color.WHITE); background = bg(0xCC333338.toInt(), 8)
            setPadding(dp(10), dp(4), dp(10), dp(4)); visibility = View.GONE
        }
        frame.addView(tip, FrameLayout.LayoutParams(WC, WC).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; bottomMargin = dp(130)
        })

        frame.setOnApplyWindowInsetsListener { v, ins ->
            val top = ins.systemWindowInsetTop
            topInset = top
            v.setPadding(0, 0, 0, ins.systemWindowInsetBottom)
            menubar.layoutParams.height = dp(28) + top
            menubar.setPadding(dp(8), top, dp(10), 0)
            launchpad.setPadding(dp(16), top + dp(16), dp(16), dp(8))
            (panel.layoutParams as FrameLayout.LayoutParams).topMargin = dp(32) + top
            ins
        }

        val root = FrameLayout(this)
        wall = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        if (wallOn) wall.setImageBitmap(decodeWall()) else wall.visibility = View.GONE
        root.addView(wall, FrameLayout.LayoutParams(MP, MP))
        root.addView(frame, FrameLayout.LayoutParams(MP, MP))
        setContentView(root)

        gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 != null && launchpad.visibility != View.VISIBLE && vy < -1500 &&
                    e1.y - e2.y > dp(100) && abs(vx) < abs(vy) && e1.y < main.height - dp(110)) openLaunchpad()
                return false
            }
        })

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED); addDataScheme("package")
        }
        registerReceiver(pkgReceiver, f)

        renderDock()      // instant: only the few dock apps are loaded here
        loadAppsAsync()   // everything else loads in the background
        if (!isHome()) Toast.makeText(this,
            "Preview mode: this is not your home screen yet. Tap \u2699 \u2192 Set as default launcher.",
            Toast.LENGTH_LONG).show()
    }

    override fun onResume() {
        super.onResume()
        if (!prefs.getBoolean("wp_set", false) && prefs.getBoolean("wall", true) && isHome()) applySystemWallpaper()
        if (panel.visibility == View.VISIBLE) updateStates()
        finder?.let { if (it.visibility == View.VISIBLE) it.refresh() }
    }

    override fun dispatchTouchEvent(e: MotionEvent): Boolean { gd.onTouchEvent(e); return super.dispatchTouchEvent(e) }
    override fun onDestroy() { unregisterReceiver(pkgReceiver); io.shutdown(); finder?.shutdown(); super.onDestroy() }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); closeLaunchpad(); hideOverlays(); hideWin(finder); hideWin(prefsWin) }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (prefsWin?.visibility == View.VISIBLE) hideWin(prefsWin)
        else if (finder?.visibility == View.VISIBLE) hideWin(finder)
        else if (helpWin.visibility == View.VISIBLE) closeHelp()
        else if (launchpad.visibility == View.VISIBLE) closeLaunchpad()
        else if (panel.visibility == View.VISIBLE) panel.visibility = View.GONE
        else if (!isHome()) finish()
    }

    // ---- data (background) ----
    private fun loadAppsAsync() {
        io.execute {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = try {
                pm.queryIntentActivities(q, 0)
                    .filter { it.activityInfo.packageName != packageName }
                    .map { r ->
                        App(r.loadLabel(pm).toString(), r.activityInfo.packageName,
                            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                                .setClassName(r.activityInfo.packageName, r.activityInfo.name)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                            r.loadIcon(pm))
                    }
                    .sortedBy { it.label.lowercase() }
            } catch (e: Exception) { emptyList() }
            runOnUiThread { if (!isDestroyed) { apps = list; render() } }
        }
    }

    private fun quickApp(pkg: String): App? = try {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) null else App(
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString(),
            pkg, i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), packageManager.getApplicationIcon(pkg))
    } catch (e: Exception) { null }

    private fun defaultDock(): List<String> {
        val intents = listOf(
            Intent(Intent.ACTION_DIAL), Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE), Intent(Settings.ACTION_SETTINGS))
        return intents.mapNotNull {
            packageManager.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        }.distinct().filter { p -> apps.any { it.pkg == p } }
    }

    private fun dockPkgs(): List<String> =
        prefs.getString("dock", null)?.split(",")?.filter { it.isNotEmpty() }
            ?: (if (apps.isEmpty()) emptyList() else defaultDock())

    // ---- rendering ----
    private fun render() {
        if (prefs.getString("dock", null) == null && apps.isNotEmpty())
            prefs.edit().putString("dock", defaultDock().joinToString(",")).apply()
        renderDock()
        renderPages()
    }

    private fun renderDock() {
        inflAnim?.cancel(); infl = 0f
        if (::tip.isInitialized) tip.visibility = View.GONE
        dockItems = listOf(finderApp, lpApp) + dockPkgs().mapNotNull { p -> apps.find { it.pkg == p } ?: quickApp(p) }
        val want = dp(32 + prefs.getInt("dsize", 16))
        val fit = (resources.displayMetrics.widthPixels - dp(40)) / dockItems.size - dp(8)
        val size = min(want, fit)
        dock.removeAllViews()
        dockItems.forEach { a ->
            dock.addView(roundIcon(a, 0), LinearLayout.LayoutParams(size, size).apply {
                setMargins(dp(4), 0, dp(4), 0)
            })
        }
    }

    private fun renderPages() {
        val per = COLS * ROWS
        val n = max(1, (apps.size + per - 1) / per)
        val cur = pager.currentItem
        pager.adapter = PageAdapter(n) { p -> page(apps.drop(p * per).take(per)) }
        pager.currentItem = min(cur, n - 1)
        dots.removeAllViews()
        for (i in 0 until n)
            dots.addView(View(this), LinearLayout.LayoutParams(dp(7), dp(7)).apply { setMargins(dp(4), 0, dp(4), 0) })
        updateDots(pager.currentItem)
    }

    private fun updateDots(sel: Int) {
        for (i in 0 until dots.childCount)
            dots.getChildAt(i).background = bg(if (i == sel) 0xFFFFFFFF.toInt() else 0x66FFFFFF, 4)
    }

    private fun page(items: List<App>): View {
        val p = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), 0, dp(8), 0) }
        for (r in 0 until ROWS) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until COLS) {
                val a = items.getOrNull(r * COLS + c)
                row.addView(if (a != null) tile(a) else View(this), LinearLayout.LayoutParams(0, MP, 1f))
            }
            p.addView(row, LinearLayout.LayoutParams(MP, 0, 1f))
        }
        return p
    }

    private fun roundIcon(a: App, size: Int) = ImageView(this).apply {
        // each view gets its own Drawable copy so bounds never clash
        setImageDrawable(a.icon.constantState?.newDrawable(resources) ?: a.icon)
        if (size > 0) layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, v.width * 0.225f) }
        }
        clipToOutline = true
    }

    private fun tile(a: App): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        box.addView(roundIcon(a, 58))
        box.addView(TextView(this).apply {
            text = a.label; setTextColor(Color.WHITE); textSize = 11f; maxLines = 1
            ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
            setShadowLayer(4f, 0f, 1f, Color.BLACK); setPadding(dp(2), dp(4), dp(2), 0)
        })
        box.setOnClickListener { launch(a) }
        box.setOnLongClickListener { menu(a); true }
        return box
    }

    // ---- dock magnification (smooth) ----
    private fun animInfl(to: Float, dur: Long) {
        inflAnim?.cancel()
        inflAnim = ValueAnimator.ofFloat(infl, to).apply {
            duration = dur; interpolator = DecelerateInterpolator()
            addUpdateListener { infl = it.animatedValue as Float; applyMag() }
            start()
        }
    }

    private fun applyMag() {
        val n = dock.childCount
        if (n == 0) return
        val s = FloatArray(n)
        val e = FloatArray(n)
        var total = 0f
        val sigma = dp(55).toFloat()
        val amp = prefs.getInt("mag", 75) / 100f * 1.2f * infl
        for (i in 0 until n) {
            val c = dock.getChildAt(i)
            val d = (lastX - (c.left + c.width / 2f)) / sigma
            s[i] = 1f + amp * exp(-d * d)
            e[i] = (s[i] - 1f) * (c.width + dp(8))
            total += e[i]
        }
        var acc = 0f
        var best = 0
        var bestS = 0f
        for (i in 0 until n) {
            val c = dock.getChildAt(i)
            c.pivotX = c.width / 2f
            c.pivotY = c.height.toFloat()
            c.scaleX = s[i]; c.scaleY = s[i]
            c.translationX = acc + e[i] / 2f - total / 2f
            acc += e[i]
            if (s[i] > bestS) { bestS = s[i]; best = i }
        }
        if (infl > 0.5f && best < dockItems.size) {
            val c = dock.getChildAt(best)
            tip.text = dockItems[best].label
            tip.visibility = View.VISIBLE
            tip.translationX = dock.x + c.left + c.width / 2f + c.translationX - main.width / 2f
        } else tip.visibility = View.GONE
    }

    private fun indexAt(x: Float): Int {
        var bi = -1
        var bd = Float.MAX_VALUE
        for (i in 0 until dock.childCount) {
            val c = dock.getChildAt(i)
            val d = abs(x - (c.left + c.width / 2f))
            if (d < bd) { bd = d; bi = i }
        }
        return bi
    }

    // double bounce of the dock icon while an app launches
    private fun bounce(pkg: String) {
        val i = dockItems.indexOfFirst { it.pkg == pkg }
        if (i < 0 || i >= dock.childCount) return
        val v = dock.getChildAt(i)
        val h = dp(26).toFloat()
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 900
            addUpdateListener {
                val t = it.animatedValue as Float
                v.translationY = -h * abs(sin(2.0 * PI * t)).toFloat() * (1f - 0.3f * t)
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) { v.translationY = 0f }
            })
            start()
        }
    }

    // ---- actions ----
    private fun launch(a: App) {
        if (a.pkg == FIN) { openFinder(); return }
        if (a.pkg == LP) { openLaunchpad(); return }
        bounce(a.pkg)
        closeLaunchpad()
        a.intent?.let { go(it) }
    }

    private fun menu(a: App) {
        if (a.pkg == LP || a.pkg == FIN) return
        val d = dockPkgs().toMutableList()
        val inDock = a.pkg in d
        val items = arrayOf(if (inDock) "Remove from Dock" else "Keep in Dock", "App info", "Uninstall")
        AlertDialog.Builder(this).setTitle(a.label).setItems(items) { _, w ->
            when (w) {
                0 -> {
                    if (inDock) d.remove(a.pkg)
                    else if (d.size < MAX_DOCK) d.add(a.pkg)
                    else Toast.makeText(this, "Dock is full", Toast.LENGTH_SHORT).show()
                    prefs.edit().putString("dock", d.joinToString(",")).apply(); renderDock()
                }
                1 -> go(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}")))
                2 -> go(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
            }
        }.show()
    }

    private fun openLaunchpad() {
        hideOverlays()
        searchInput.setText("")
        filter("")
        pager.currentItem = 0
        launchpad.alpha = 0f; launchpad.scaleX = 1.12f; launchpad.scaleY = 1.12f
        launchpad.visibility = View.VISIBLE
        launchpad.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).start()
    }

    private fun closeLaunchpad() {
        if (launchpad.visibility != View.VISIBLE) return
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(searchInput.windowToken, 0)
        launchpad.animate().alpha(0f).scaleX(1.12f).scaleY(1.12f).setDuration(160)
            .withEndAction { launchpad.visibility = View.GONE }.start()
    }

    private fun filter(q: String) {
        results.removeAllViews()
        if (q.isBlank()) {
            matches = apps; pager.visibility = View.VISIBLE; resultsScroll.visibility = View.GONE; return
        }
        matches = apps.filter { it.label.contains(q.trim(), true) }
        pager.visibility = View.GONE; resultsScroll.visibility = View.VISIBLE
        matches.take(40).forEach { a ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(8), dp(8), dp(8)); setOnClickListener { launch(a) }
            }
            row.addView(roundIcon(a, 44))
            row.addView(TextView(this).apply {
                text = a.label; textSize = 16f; setTextColor(Color.WHITE); setPadding(dp(14), 0, 0, 0)
            })
            results.addView(row)
        }
    }

    // ---- menu bar: logo menu, clock panel, help ----
    private fun logoMenu(v: View) {
        val m = PopupMenu(this, v)
        m.menu.add(0, 1, 0, "About This Launcher")
        m.menu.add(0, 2, 1, "System Preferences\u2026")
        m.menu.add(0, 3, 2, "Finder")
        m.menu.add(0, 4, 3, "Launchpad")
        m.menu.add(0, 5, 4, "Set as Default Launcher\u2026")
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> openPrefs("About")
                2 -> openPrefs(null)
                3 -> openFinder()
                4 -> openLaunchpad()
                else -> go(Intent(Settings.ACTION_HOME_SETTINGS))
            }
            true
        }
        m.show()
    }

    private fun fileMenu(v: View) {
        val m = PopupMenu(this, v)
        m.menu.add(0, 1, 0, "New Finder Window")
        m.menu.add(0, 2, 1, "Open Launchpad")
        m.setOnMenuItemClickListener { if (it.itemId == 1) openFinder() else openLaunchpad(); true }
        m.show()
    }

    private fun showWin(v: View) {
        v.alpha = 0f; v.scaleX = 0.94f; v.scaleY = 0.94f; v.visibility = View.VISIBLE
        v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start()
    }

    private fun hideWin(v: View?) {
        if (v == null || v.visibility != View.VISIBLE) return
        v.animate().alpha(0f).scaleX(0.94f).scaleY(0.94f).setDuration(140).withEndAction { v.visibility = View.GONE }.start()
    }

    private fun openFinder() {
        hideOverlays(); hideWin(prefsWin); closeLaunchpad()
        var f = finder
        if (f == null) {
            f = FinderWindow(this) { hideWin(finder) }
            finder = f
            frameRef.addView(f, frameRef.indexOfChild(tip),
                FrameLayout.LayoutParams(MP, MP).apply { setMargins(dp(8), topInset + dp(34), dp(8), dp(112)) })
        }
        f.refresh()
        showWin(f)
    }

    private fun openPrefs(pane: String?) {
        hideOverlays(); hideWin(finder); closeLaunchpad()
        var w = prefsWin
        if (w == null) {
            w = PrefsWindow(this, object : PrefsHost {
                override fun showWall(on: Boolean) { this@MainActivity.showWall(on) }
                override fun applyClock() { this@MainActivity.applyClock() }
                override fun renderDock() { this@MainActivity.renderDock() }
                override fun applyWallpaper() { applySystemWallpaper() }
                override fun resetDock() { prefs.edit().remove("dock").apply(); render() }
                override fun isHome() = this@MainActivity.isHome()
                override fun close() { hideWin(prefsWin) }
            })
            prefsWin = w
            frameRef.addView(w, frameRef.indexOfChild(tip), FrameLayout.LayoutParams(
                min(dp(360), resources.displayMetrics.widthPixels - dp(24)),
                (resources.displayMetrics.heightPixels * 0.66f).toInt()).apply { gravity = Gravity.CENTER })
        }
        w.showHome()
        if (pane != null) w.showPaneByName(pane)
        showWin(w)
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        finder?.refresh()
    }

    private fun hideOverlays() {
        panel.visibility = View.GONE
        if (helpWin.visibility == View.VISIBLE) closeHelp()
    }

    private fun applyClock() {
        val f = if (prefs.getBoolean("h24", true)) "EEE  HH:mm" else "EEE  h:mm a"
        clockView.format12Hour = f; clockView.format24Hour = f
    }

    private fun togglePanel() {
        if (panel.visibility == View.VISIBLE) { panel.visibility = View.GONE; return }
        if (helpWin.visibility == View.VISIBLE) closeHelp()
        month.timeInMillis = System.currentTimeMillis()
        fillCalendar(); updateStates()
        panel.visibility = View.VISIBLE
    }

    private fun cell(t: String, today: Boolean, color: Int) = TextView(this).apply {
        text = t; textSize = 13f; gravity = Gravity.CENTER; setTextColor(color)
        if (today) background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFFFF453A.toInt()) }
    }

    private fun fillCalendar() {
        val c = month.clone() as Calendar
        c.set(Calendar.DAY_OF_MONTH, 1)
        calTitle.text = android.text.format.DateFormat.format("LLLL yyyy", c).toString()
        calGrid.removeAllViews()
        val first = c.firstDayOfWeek
        val names = arrayOf("S", "M", "T", "W", "T", "F", "S")
        val hdr = LinearLayout(this)
        for (k in 0 until 7)
            hdr.addView(cell(names[(first - 1 + k) % 7], false, 0x99FFFFFF.toInt()), LinearLayout.LayoutParams(0, dp(26), 1f))
        calGrid.addView(hdr)
        val offset = (c.get(Calendar.DAY_OF_WEEK) - first + 7) % 7
        val days = c.getActualMaximum(Calendar.DAY_OF_MONTH)
        val now = Calendar.getInstance()
        var r = 0
        while (r * 7 - offset + 1 <= days) {
            val row = LinearLayout(this)
            for (k in 0 until 7) {
                val n = r * 7 + k - offset + 1
                val ok = n in 1..days
                val today = ok && c.get(Calendar.YEAR) == now.get(Calendar.YEAR) &&
                    c.get(Calendar.MONTH) == now.get(Calendar.MONTH) && n == now.get(Calendar.DAY_OF_MONTH)
                row.addView(cell(if (ok) n.toString() else "", today, Color.WHITE), LinearLayout.LayoutParams(0, dp(30), 1f))
            }
            calGrid.addView(row)
            r++
        }
    }

    private fun setTile(t: TextView, on: Boolean) { t.background = bg(if (on) 0xFF0A84FF.toInt() else 0x33FFFFFF, 12) }

    private fun updateStates() {
        try { setTile(wifiTile, (applicationContext.getSystemService(WIFI_SERVICE) as WifiManager).isWifiEnabled) } catch (e: Exception) { }
        try { setTile(btTile, BluetoothAdapter.getDefaultAdapter()?.isEnabled == true) } catch (e: Exception) { }
        try { setTile(apTile, Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1) } catch (e: Exception) { }
        try { brightSeek.progress = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) } catch (e: Exception) { }
        try {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            volSeek.max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            volSeek.progress = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        } catch (e: Exception) { }
    }

    private fun tileView(label: String, on: () -> Unit) = TextView(this).apply {
        text = label; gravity = Gravity.CENTER; textSize = 12f; setTextColor(Color.WHITE)
        setPadding(0, dp(12), 0, dp(12)); background = bg(0x33FFFFFF, 12)
        setOnClickListener { panel.visibility = View.GONE; on() }
    }

    private fun buildPanel(): LinearLayout {
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bg(0xF026262B.toInt(), 16)
            setPadding(dp(12), dp(10), dp(12), dp(10)); visibility = View.GONE
        }
        fun arrow(t: String, d: Int) = TextView(this).apply {
            text = t; textSize = 22f; setTextColor(Color.WHITE); setPadding(dp(12), 0, dp(12), 0)
            setOnClickListener { month.add(Calendar.MONTH, d); fillCalendar() }
        }
        fun lab(t: String) = TextView(this).apply {
            text = t; textSize = 12f; setTextColor(0xCCFFFFFF.toInt()); setPadding(0, dp(10), 0, 0)
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        calTitle = TextView(this).apply { textSize = 15f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD }
        head.addView(calTitle, LinearLayout.LayoutParams(0, WC, 1f))
        head.addView(arrow("\u2039", -1))
        head.addView(arrow("\u203A", 1))
        p.addView(head)
        calGrid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        p.addView(calGrid, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(6) })

        wifiTile = tileView("Wi-Fi") {
            if (Build.VERSION.SDK_INT >= 29) go(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
            else go(Intent(Settings.ACTION_WIFI_SETTINGS))
        }
        btTile = tileView("Bluetooth") { go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
        apTile = tileView("Airplane") { go(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)) }
        val row = LinearLayout(this)
        listOf(wifiTile, btTile, apTile).forEach {
            row.addView(it, LinearLayout.LayoutParams(0, WC, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        p.addView(row, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(10) })

        p.addView(lab("Display"))
        brightSeek = SeekBar(this).apply {
            max = 255
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, v: Int, user: Boolean) {
                    if (user && Settings.System.canWrite(this@MainActivity)) {
                        Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                            Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                        Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, if (v < 1) 1 else v)
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {
                    if (!Settings.System.canWrite(this@MainActivity))
                        go(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + packageName)))
                }
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        p.addView(brightSeek)
        p.addView(lab("Sound"))
        volSeek = SeekBar(this).apply {
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, v: Int, user: Boolean) {
                    if (user) try {
                        (this@MainActivity.getSystemService(AUDIO_SERVICE) as AudioManager)
                            .setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)
                    } catch (e: Exception) { }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        p.addView(volSeek)
        p.addView(TextView(this).apply {
            text = "System Preferences\u2026"; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = bg(0x55007AFF, 10); setPadding(dp(12), dp(10), dp(12), dp(10))
            setOnClickListener { panel.visibility = View.GONE; settings() }
        }, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(12) })
        return p
    }

    private val helpText = """Добро пожаловать!

Док
Проведи пальцем по доку: иконки плавно увеличиваются, как в macOS. Тап запускает приложение, долгое нажатие открывает меню: оставить в доке, информация о приложении, удалить. При запуске иконка прыгает дважды.

Finder
Первая иконка дока: файловый менеджер. Слева избранные папки, сверху назад, вперёд, вверх, поиск и переключение списка и значков. Долгое нажатие на файл: переименовать, копировать, вырезать, поделиться, информация, удалить. Кнопка ⋯: новая папка, вставить, скрытые файлы, сортировка. При первом запуске разреши доступ к файлам.

Launchpad
Вторая иконка дока или свайп вверх по рабочему столу. Сверху поиск, страницы листаются вбок. Долгое нажатие на приложение открывает то же меню.

Строка меню
Значок слева открывает меню лаунчера. Нажми на время: откроется календарь, переключатели Wi-Fi, Bluetooth и авиарежима, ползунки яркости и громкости. Для яркости один раз разреши «Изменение системных настроек». Значок ⚙ открывает System Preferences.

Настройки
Встроенные обои, размер дока, сила увеличения, формат времени, кнопки «Set as default launcher» и «Apply wallpaper». Долгое нажатие на пустое место рабочего стола тоже открывает настройки.

Режим просмотра
Пока лаунчер не выбран главным, он работает как обычное приложение и ничего не меняет в системе.

Вернуть прежний лаунчер
Настройки Android → Приложения → Приложения по умолчанию → Главный экран."""

    private fun buildHelp(): LinearLayout {
        val w = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bg(0xF21E1E22.toInt(), 14)
            visibility = View.GONE; isClickable = true
        }
        fun dot(c: Int, click: (() -> Unit)?) = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
            if (click != null) setOnClickListener { click() }
        }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)) }
        for ((i, c) in listOf(0xFFFF5F57.toInt(), 0xFFFFBD2E.toInt(), 0xFF28C840.toInt()).withIndex())
            bar.addView(dot(c, if (i == 0) ({ closeHelp() }) else null),
                LinearLayout.LayoutParams(dp(13), dp(13)).apply { rightMargin = dp(8) })
        bar.addView(TextView(this).apply {
            text = "Help"; textSize = 14f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, WC, 1f))
        bar.addView(View(this), LinearLayout.LayoutParams(dp(55), 1))
        w.addView(bar)
        w.addView(View(this).apply { setBackgroundColor(0x22FFFFFF) }, LinearLayout.LayoutParams(MP, 1))
        w.addView(ScrollView(this).apply {
            addView(TextView(this@MainActivity).apply {
                text = helpText; textSize = 14f; setTextColor(0xEEFFFFFF.toInt())
                setLineSpacing(0f, 1.15f); setPadding(dp(18), dp(14), dp(18), dp(18))
            })
        }, LinearLayout.LayoutParams(MP, 0, 1f))
        return w
    }

    private fun showHelp() {
        panel.visibility = View.GONE
        helpWin.alpha = 0f; helpWin.scaleX = 0.92f; helpWin.scaleY = 0.92f
        helpWin.visibility = View.VISIBLE
        helpWin.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start()
    }

    private fun closeHelp() {
        helpWin.animate().alpha(0f).scaleX(0.92f).scaleY(0.92f).setDuration(140)
            .withEndAction { helpWin.visibility = View.GONE }.start()
    }

    // ---- wallpaper, settings, home detection ----
    private fun isHome(): Boolean {
        val r = packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY)
        return r?.activityInfo?.packageName == packageName
    }

    private fun applySystemWallpaper() {
        prefs.edit().putBoolean("wp_set", true).apply()
        io.execute {
            try {
                val bmp = BitmapFactory.decodeResource(resources, R.drawable.wallpaper)
                WallpaperManager.getInstance(this)
                    .setBitmap(bmp, null, true, WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK)
                bmp.recycle()
                runOnUiThread { Toast.makeText(this, "Wallpaper applied to Home and Lock screen", Toast.LENGTH_SHORT).show() }
            } catch (e: Exception) { prefs.edit().putBoolean("wp_set", false).apply() }
        }
    }

    private fun showWall(on: Boolean) {
        if (on) {
            if (wall.drawable == null) wall.setImageBitmap(decodeWall())
            wall.visibility = View.VISIBLE
            window.setBackgroundDrawableResource(R.drawable.ic_bg)
        } else {
            wall.visibility = View.GONE
            wall.setImageDrawable(null)
            window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        }
    }

    private fun settings() { openPrefs(null) }
}
