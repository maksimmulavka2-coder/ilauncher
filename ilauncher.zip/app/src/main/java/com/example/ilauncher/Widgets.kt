package com.example.ilauncher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import java.util.Calendar
import kotlin.math.min

// Analog desktop clock. Ticks once a second, and only while the window is visible.
internal class ClockWidget(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tick = object : Runnable {
        override fun run() { invalidate(); postDelayed(this, 1000L - System.currentTimeMillis() % 1000L) }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); removeCallbacks(tick); post(tick) }
    override fun onDetachedFromWindow() { removeCallbacks(tick); super.onDetachedFromWindow() }
    override fun onWindowVisibilityChanged(v: Int) {
        super.onWindowVisibilityChanged(v)
        removeCallbacks(tick)
        if (v == View.VISIBLE) post(tick)
    }

    private fun hand(c: Canvas, cx: Float, cy: Float, deg: Float, len: Float, w: Float, color: Int) {
        p.color = color; p.strokeWidth = w; p.strokeCap = Paint.Cap.ROUND
        c.save(); c.rotate(deg, cx, cy)
        c.drawLine(cx, cy + len * 0.12f, cx, cy - len, p)
        c.restore()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2; val cy = h / 2; val r = min(w, h) / 2
        p.style = Paint.Style.FILL; p.color = 0x66000000
        c.drawRoundRect(0f, 0f, w, h, r * 0.3f, r * 0.3f, p)
        p.color = 0xF5FFFFFF.toInt()
        c.drawCircle(cx, cy, r * 0.8f, p)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.BUTT
        for (i in 0 until 12) {
            val big = i % 3 == 0
            p.color = 0xFF3A3A3C.toInt(); p.strokeWidth = if (big) r * 0.045f else r * 0.02f
            c.save(); c.rotate(i * 30f, cx, cy)
            c.drawLine(cx, cy - r * 0.72f, cx, cy - r * (if (big) 0.6f else 0.65f), p)
            c.restore()
        }
        val cal = Calendar.getInstance()
        val s = cal.get(Calendar.SECOND); val m = cal.get(Calendar.MINUTE); val hr = cal.get(Calendar.HOUR)
        hand(c, cx, cy, (hr + m / 60f) * 30f, r * 0.45f, r * 0.07f, 0xFF1C1C1E.toInt())
        hand(c, cx, cy, (m + s / 60f) * 6f, r * 0.68f, r * 0.045f, 0xFF1C1C1E.toInt())
        hand(c, cx, cy, s * 6f, r * 0.7f, r * 0.02f, 0xFFFF9500.toInt())
        p.style = Paint.Style.FILL; p.color = 0xFFFF9500.toInt()
        c.drawCircle(cx, cy, r * 0.045f, p)
    }
}
