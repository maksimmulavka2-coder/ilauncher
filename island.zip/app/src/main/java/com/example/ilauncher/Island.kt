package com.example.ilauncher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Notification
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.text.TextUtils
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.Outline
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// Animated equalizer bars. Ticks only while visible and playing.
internal class EqualizerView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF30D158.toInt() }
    private var on = true
    private val tick = object : Runnable {
        override fun run() { invalidate(); if (on) postDelayed(this, 40) }
    }

    fun setPlaying(b: Boolean) {
        on = b
        removeCallbacks(tick)
        if (b && isAttachedToWindow) post(tick) else invalidate()
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (on) post(tick) }
    override fun onDetachedFromWindow() { removeCallbacks(tick); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val bw = w / 7f
        val t = System.currentTimeMillis() / 1000.0
        for (i in 0 until 4) {
            val f = if (on) 0.3f + 0.7f * abs(sin(t * (3.0 + i) + i * 1.7)).toFloat() else 0.25f
            val bh = h * f
            val x = bw * i * 2
            c.drawRoundRect(RectF(x, (h - bh) / 2, x + bw, (h + bh) / 2), bw / 2, bw / 2, p)
        }
    }
}

internal class BatteryView(c: Context, private val level: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val sw = h * 0.1f
        p.style = Paint.Style.STROKE; p.strokeWidth = sw; p.color = 0xAAFFFFFF.toInt()
        c.drawRoundRect(RectF(sw, sw, w * 0.9f - sw, h - sw), h * 0.25f, h * 0.25f, p)
        p.style = Paint.Style.FILL; p.color = 0xFF30D158.toInt()
        val inner = (w * 0.9f - 4 * sw) * level.coerceIn(0, 100) / 100f
        c.drawRoundRect(RectF(2 * sw, 2 * sw, 2 * sw + inner, h - 2 * sw), h * 0.15f, h * 0.15f, p)
        p.color = 0xAAFFFFFF.toInt()
        c.drawRoundRect(RectF(w * 0.92f, h * 0.35f, w, h * 0.65f), sw, sw, p)
    }
}

// kind: 0 previous, 1 play, 2 pause, 3 next
internal class MediaGlyph(private val kind: Int) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    private fun tri(c: Canvas, l: Float, t: Float, w: Float, h: Float, x1: Float, x2: Float) {
        val path = Path()
        path.moveTo(l + w * x1, t + h * 0.2f)
        path.lineTo(l + w * x2, t + h * 0.5f)
        path.lineTo(l + w * x1, t + h * 0.8f)
        path.close()
        c.drawPath(path, p)
    }

    override fun draw(c: Canvas) {
        val b = bounds
        val l = b.left.toFloat(); val t = b.top.toFloat()
        val w = b.width().toFloat(); val h = b.height().toFloat()
        when (kind) {
            1 -> tri(c, l, t, w, h, 0.25f, 0.85f)
            2 -> {
                c.drawRoundRect(RectF(l + w * 0.2f, t + h * 0.15f, l + w * 0.42f, t + h * 0.85f), 4f, 4f, p)
                c.drawRoundRect(RectF(l + w * 0.58f, t + h * 0.15f, l + w * 0.8f, t + h * 0.85f), 4f, 4f, p)
            }
            3 -> {
                tri(c, l, t, w, h, 0.1f, 0.5f); tri(c, l, t, w, h, 0.45f, 0.85f)
                c.drawRoundRect(RectF(l + w * 0.85f, t + h * 0.2f, l + w * 0.93f, t + h * 0.8f), 3f, 3f, p)
            }
            else -> {
                tri(c, l, t, w, h, 0.9f, 0.5f); tri(c, l, t, w, h, 0.55f, 0.15f)
                c.drawRoundRect(RectF(l + w * 0.07f, t + h * 0.2f, l + w * 0.15f, t + h * 0.8f), 3f, 3f, p)
            }
        }
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}

/**
 * Dynamic Island. Runs as a notification listener (so the system keeps it alive and gives
 * it notifications and media sessions) and draws a black pill in an overlay window.
 * Modes: 0 idle, 1 music compact, 2 music expanded, 3 notification, 4 charging.
 */
class IslandService : NotificationListenerService() {
    companion object {
        @Volatile var instance: IslandService? = null
    }

    private val h = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("l", 0) }
    private val msm by lazy { getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager }
    private val cn by lazy { ComponentName(this, IslandService::class.java) }
    private var wm: WindowManager? = null
    private var host: FrameLayout? = null
    private var island: FrameLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private val bgDraw = GradientDrawable().apply { setColor(Color.BLACK) }
    private var attached = false
    private var anim: ValueAnimator? = null
    private var mode = 0
    private var curW = 0
    private var curH = 0
    private var forcePill = false
    private var controller: MediaController? = null
    private var title = ""
    private var artist = ""
    private var art: Bitmap? = null
    private var playing = false
    private var nApp = ""
    private var nTitle = ""
    private var nText = ""
    private var nIcon: Drawable? = null
    private var nIntent: PendingIntent? = null
    private var lastKey = ""
    private var lastTime = 0L
    private var chargeLevel = 0
    private var fill: View? = null
    private lateinit var gd: GestureDetector

    private val settleR = Runnable { settle() }
    private val hidePillR = Runnable { forcePill = false; settle() }
    private val progressR = object : Runnable {
        override fun run() { updateProgress(); if (mode == 2) h.postDelayed(this, 500) }
    }
    private val powerReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { showCharge() }
    }
    private val sessionListener = MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }
    private val mcb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) { refreshMedia() }
        override fun onMetadataChanged(metadata: MediaMetadata?) { refreshMedia() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun pillW() = dp(80 + prefs.getInt("isl_w", 44))
    private fun pillH() = dp(26 + prefs.getInt("isl_h", 8))
    private fun topY() = dp(prefs.getInt("isl_y", 10))
    private fun screenW() = resources.displayMetrics.widthPixels

    private fun sizeFor(m: Int): Pair<Int, Int> = when (m) {
        1 -> Pair(pillW() + dp(64), pillH())
        2 -> Pair(min(screenW() - dp(24), dp(380)), dp(170))
        3 -> Pair(min(screenW() - dp(24), dp(380)), dp(88))
        4 -> Pair(min(screenW() - dp(60), dp(300)), dp(76))
        else -> Pair(pillW(), pillH())
    }

    private fun enabled() = prefs.getBoolean("isl_on", true) && Settings.canDrawOverlays(this)

    // ---- lifecycle ----
    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean { onTap(); return true }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (vy < -800f) { settle(); return true }
                return false
            }
        })
        registerReceiver(powerReceiver, IntentFilter(Intent.ACTION_POWER_CONNECTED))
        try {
            msm.addOnActiveSessionsChangedListener(sessionListener, cn)
            pick(msm.getActiveSessions(cn))
        } catch (e: Exception) { }
        applySettings()
    }

    override fun onListenerDisconnected() { cleanup(); super.onListenerDisconnected() }
    override fun onDestroy() { cleanup(); super.onDestroy() }

    private fun cleanup() {
        instance = null
        try { unregisterReceiver(powerReceiver) } catch (e: Exception) { }
        try { msm.removeOnActiveSessionsChangedListener(sessionListener) } catch (e: Exception) { }
        controller?.unregisterCallback(mcb)
        controller = null
        removeWindow()
    }

    fun applySettings(showPill: Boolean = false) {
        if (!enabled()) { removeWindow(); return }
        if (showPill && mode == 0) {
            forcePill = true
            h.removeCallbacks(hidePillR)
            h.postDelayed(hidePillR, 2500)
        }
        settle()
    }

    fun demo(kind: Int) {
        if (!enabled()) return
        when (kind) {
            0 -> {
                nApp = "Messages"; nTitle = "Alex"; nText = "Are we still on for tonight?"
                nIcon = try { packageManager.getApplicationIcon(packageName) } catch (e: Exception) { null }
                nIntent = null
                go(3); h.removeCallbacks(settleR); h.postDelayed(settleR, 4000)
            }
            1 -> {
                title = "Midnight City"; artist = "Demo Artist"
                go(2); h.removeCallbacks(settleR); h.postDelayed(settleR, 6000)
            }
            else -> showCharge()
        }
    }

    // ---- events ----
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!enabled() || sbn.packageName == packageName || sbn.isOngoing) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.category == Notification.CATEGORY_TRANSPORT) return
        val e = n.extras
        val t = e.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val txt = e.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val key = sbn.packageName + t + txt
        val now = SystemClock.elapsedRealtime()
        if (key == lastKey && now - lastTime < 3000) return
        lastKey = key; lastTime = now
        nApp = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString() } catch (x: Exception) { "" }
        nIcon = try { packageManager.getApplicationIcon(sbn.packageName) } catch (x: Exception) { null }
        nTitle = t; nText = txt; nIntent = n.contentIntent
        go(3)
        h.removeCallbacks(settleR); h.postDelayed(settleR, 4000)
    }

    private fun showCharge() {
        if (!enabled()) return
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lv = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        chargeLevel = if (sc > 0) lv * 100 / sc else lv
        go(4)
        h.removeCallbacks(settleR); h.postDelayed(settleR, 3500)
    }

    private fun pick(list: List<MediaController>?) {
        controller?.unregisterCallback(mcb)
        controller = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list?.firstOrNull()
        controller?.registerCallback(mcb, h)
        refreshMedia()
    }

    private fun refreshMedia() {
        val c = controller
        playing = c?.playbackState?.state == PlaybackState.STATE_PLAYING
        val md = c?.metadata
        title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
        artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        art = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        if (!enabled()) return
        when (mode) {
            0, 1 -> settle()
            2 -> if (c == null) settle() else go(2)
        }
    }

    private fun settle() {
        h.removeCallbacks(settleR)
        go(if (playing) 1 else 0)
    }

    private fun onTap() {
        when (mode) {
            1 -> { go(2); h.removeCallbacks(settleR); h.postDelayed(settleR, 7000) }
            3 -> { try { nIntent?.send() } catch (e: Exception) { }; settle() }
            else -> settle()
        }
    }

    // ---- window ----
    private fun go(m: Int) {
        if (!enabled()) return
        if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) { removeWindow(); return }
        if (m == 0 && !prefs.getBoolean("isl_always", false) && !forcePill) {
            if (attached) { mode = 0; setContent(null, 0, 0); morph(pillW(), pillH()) { removeWindow() } }
            return
        }
        ensureWindow()
        mode = m
        val (w, hh) = sizeFor(m)
        setContent(build(m), w, hh)
        morph(w, hh, null)
        h.removeCallbacks(progressR)
        if (m == 2) h.post(progressR)
    }

    private fun ensureWindow() {
        if (attached) return
        val manager = wm ?: return
        val hostV = FrameLayout(this)
        val isl = FrameLayout(this)
        isl.background = bgDraw
        isl.outlineProvider = ViewOutlineProvider.BACKGROUND
        isl.clipToOutline = true
        isl.setOnTouchListener { _, e -> gd.onTouchEvent(e); true }
        curW = pillW(); curH = pillH()
        bgDraw.cornerRadius = min(curH / 2f, dp(34).toFloat())
        hostV.addView(isl, FrameLayout.LayoutParams(curW, curH, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        val l = WindowManager.LayoutParams(
            curW, curH, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        l.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        l.y = topY()
        if (Build.VERSION.SDK_INT >= 30) l.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        else if (Build.VERSION.SDK_INT >= 28) l.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        try {
            manager.addView(hostV, l)
            host = hostV; island = isl; lp = l; attached = true
        } catch (e: Exception) { }
    }

    private fun removeWindow() {
        anim?.cancel()
        h.removeCallbacks(settleR); h.removeCallbacks(progressR)
        if (attached) {
            try { wm?.removeView(host) } catch (e: Exception) { }
        }
        attached = false; host = null; island = null; lp = null; mode = 0
    }

    private fun updateLp(w: Int, hh: Int) {
        val l = lp ?: return
        val hv = host ?: return
        l.width = w; l.height = hh; l.y = topY()
        try { wm?.updateViewLayout(hv, l) } catch (e: Exception) { }
    }

    private fun applySize() {
        val isl = island ?: return
        val p = isl.layoutParams as FrameLayout.LayoutParams
        p.width = curW; p.height = max(curH, 1)
        isl.layoutParams = p
        bgDraw.cornerRadius = min(curH / 2f, dp(34).toFloat())
        isl.invalidateOutline()
    }

    // Springy morph. The window is first made big enough for both sizes, then the black pill
    // animates inside it, and the window shrinks again when the animation ends.
    private fun morph(w: Int, hh: Int, after: (() -> Unit)?) {
        if (island == null) return
        anim?.cancel()
        updateLp(max(curW, w), max(curH, hh))
        val fw = curW
        val fh = curH
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 450
            interpolator = OvershootInterpolator(1.1f)
            addUpdateListener {
                val t = it.animatedValue as Float
                curW = (fw + (w - fw) * t).toInt()
                curH = (fh + (hh - fh) * t).toInt()
                applySize()
            }
            addListener(object : AnimatorListenerAdapter() {
                var cancelled = false
                override fun onAnimationCancel(a: Animator) { cancelled = true }
                override fun onAnimationEnd(a: Animator) {
                    if (cancelled) return
                    curW = w; curH = hh
                    applySize()
                    updateLp(w, hh)
                    after?.invoke()
                }
            })
            start()
        }
    }

    private fun setContent(v: View?, w: Int, hh: Int) {
        val isl = island ?: return
        isl.removeAllViews()
        if (v == null) return
        v.alpha = 0f
        isl.addView(v, FrameLayout.LayoutParams(w, hh, Gravity.CENTER))
        v.animate().alpha(1f).setStartDelay(140).setDuration(200).start()
    }

    // ---- content ----
    private fun build(m: Int): View? = when (m) {
        1 -> compact()
        2 -> expanded()
        3 -> notif()
        4 -> charge()
        else -> null
    }

    private fun tv(t: String, sp: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(color); maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun rounded(v: View, r: Int) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, o: Outline) { o.setRoundRect(0, 0, view.width, view.height, dp(r).toFloat()) }
        }
        v.clipToOutline = true
    }

    private fun artView(): ImageView {
        val v = ImageView(this)
        v.scaleType = ImageView.ScaleType.CENTER_CROP
        v.background = GradientDrawable().apply { setColor(0xFF3A3A3C.toInt()) }
        val b = art
        if (b != null) v.setImageBitmap(b)
        rounded(v, 10)
        return v
    }

    private fun compact(): View {
        val r = FrameLayout(this)
        val s = pillH() - dp(12)
        r.addView(artView(), FrameLayout.LayoutParams(s, s, Gravity.START or Gravity.CENTER_VERTICAL).apply { marginStart = dp(8) })
        val eq = EqualizerView(this)
        eq.setPlaying(playing)
        r.addView(eq, FrameLayout.LayoutParams(dp(18), pillH() - dp(16), Gravity.END or Gravity.CENTER_VERTICAL).apply { marginEnd = dp(12) })
        return r
    }

    private fun ctl(kind: Int, click: () -> Unit): ImageView {
        val v = ImageView(this)
        v.setImageDrawable(MediaGlyph(kind))
        v.setPadding(dp(5), dp(5), dp(5), dp(5))
        v.setOnClickListener {
            h.removeCallbacks(settleR); h.postDelayed(settleR, 7000)
            click()
        }
        return v
    }

    private fun expanded(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(14), dp(16), dp(10))
        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(artView(), LinearLayout.LayoutParams(dp(58), dp(58)))
        val tc = LinearLayout(this)
        tc.orientation = LinearLayout.VERTICAL
        tc.setPadding(dp(12), 0, dp(8), 0)
        tc.addView(tv(if (title.isEmpty()) "Not Playing" else title, 15f, Color.WHITE, true))
        tc.addView(tv(artist, 13f, 0xAAFFFFFF.toInt(), false))
        top.addView(tc, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val eq = EqualizerView(this)
        eq.setPlaying(playing)
        top.addView(eq, LinearLayout.LayoutParams(dp(22), dp(26)))
        col.addView(top)

        val track = FrameLayout(this)
        track.background = GradientDrawable().apply { setColor(0x44FFFFFF); cornerRadius = dp(2).toFloat() }
        val f = View(this)
        f.background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(2).toFloat() }
        f.pivotX = 0f
        f.scaleX = 0f
        track.addView(f, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        fill = f
        col.addView(track, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(4)).apply { topMargin = dp(12) })

        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER
        val gap = LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(dp(14), 0, dp(14), 0) }
        row.addView(ctl(0) { controller?.transportControls?.skipToPrevious() }, gap)
        row.addView(ctl(if (playing) 2 else 1) {
            if (playing) controller?.transportControls?.pause() else controller?.transportControls?.play()
        }, LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(dp(14), 0, dp(14), 0) })
        row.addView(ctl(3) { controller?.transportControls?.skipToNext() },
            LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(dp(14), 0, dp(14), 0) })
        col.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        return col
    }

    private fun updateProgress() {
        val c = controller ?: return
        val f = fill ?: return
        val st = c.playbackState ?: return
        val dur = c.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        if (dur <= 0L) { f.scaleX = 0f; return }
        var pos = st.position
        if (st.state == PlaybackState.STATE_PLAYING)
            pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
        f.scaleX = (pos.toFloat() / dur).coerceIn(0f, 1f)
    }

    private fun notif(): View {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(16), dp(10), dp(16), dp(10))
        val ic = ImageView(this)
        ic.setImageDrawable(nIcon)
        rounded(ic, 12)
        r.addView(ic, LinearLayout.LayoutParams(dp(46), dp(46)))
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(12), 0, 0, 0)
        c.addView(tv(nApp, 11f, 0x99FFFFFF.toInt(), false))
        c.addView(tv(nTitle, 15f, Color.WHITE, true))
        val body = tv(nText, 13f, 0xCCFFFFFF.toInt(), false)
        body.maxLines = 2
        c.addView(body)
        r.addView(c, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return r
    }

    private fun charge(): View {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(22), 0, dp(22), 0)
        r.addView(tv("Charging", 15f, Color.WHITE, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(tv("$chargeLevel%", 22f, 0xFF30D158.toInt(), true))
        r.addView(BatteryView(this, chargeLevel), LinearLayout.LayoutParams(dp(30), dp(16)).apply { marginStart = dp(8) })
        return r
    }
}
