package com.example.ilauncher

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat

// Settings screen for the Dynamic Island. The island itself lives in IslandService.
class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("l", 0) }
    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT
    private lateinit var overlayTv: TextView
    private lateinit var listenerTv: TextView
    private lateinit var runTv: TextView
    private lateinit var overlayBtn: TextView
    private lateinit var listenerBtn: TextView
    private var retries = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun go(i: Intent) { try { startActivity(i) } catch (e: Exception) { } }
    private fun top(m: Int) = LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(m) }

    private fun label(t: String) = TextView(this).apply {
        text = t; textSize = 13f; setTextColor(0xAAFFFFFF.toInt()); setPadding(0, dp(18), 0, dp(2))
    }

    private fun status() = TextView(this).apply {
        textSize = 15f; setTextColor(Color.WHITE); setPadding(0, dp(12), 0, 0)
    }

    private fun btn(t: String, a: () -> Unit) = TextView(this).apply {
        text = t; textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        background = bg(0x33FFFFFF, 12); setPadding(dp(12), dp(13), dp(12), dp(13)); setOnClickListener { a() }
    }

    private fun sw(t: String, key: String, def: Boolean) = Switch(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 15f; setPadding(0, dp(12), 0, dp(4))
        isChecked = prefs.getBoolean(key, def)
        setOnCheckedChangeListener { _, c ->
            prefs.edit().putBoolean(key, c).apply()
            IslandService.instance?.applySettings(true)
        }
    }

    private fun seek(top: Int, key: String, def: Int) = SeekBar(this).apply {
        max = top; progress = prefs.getInt(key, def)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) {
                prefs.edit().putInt(key, p).apply()
                if (u) IslandService.instance?.applySettings(true)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(24), dp(20), dp(32))
        box.addView(TextView(this).apply {
            text = "Dynamic Island"; textSize = 30f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        })
        box.addView(TextView(this).apply {
            text = "Notifications, music and charging in a pill at the top of the screen."
            textSize = 14f; setTextColor(0xAAFFFFFF.toInt()); setPadding(0, dp(4), 0, dp(10))
        })

        overlayTv = status()
        overlayBtn = btn("Allow display over other apps") {
            go(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
        }
        listenerTv = status()
        listenerBtn = btn("Allow notification access") { go(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        runTv = status()
        box.addView(overlayTv); box.addView(overlayBtn, top(6))
        box.addView(listenerTv); box.addView(listenerBtn, top(6))
        box.addView(runTv)

        box.addView(sw("Dynamic Island", "isl_on", true), top(14))
        box.addView(sw("Always show the pill", "isl_always", false))
        box.addView(label("Width"))
        box.addView(seek(100, "isl_w", 44))
        box.addView(label("Height"))
        box.addView(seek(20, "isl_h", 8))
        box.addView(label("Distance from the top"))
        box.addView(seek(40, "isl_y", 10))

        box.addView(label("Preview"))
        val row = LinearLayout(this)
        listOf("Message", "Music", "Charging").forEachIndexed { i, n ->
            row.addView(btn(n) {
                val s = IslandService.instance
                if (s == null) Toast.makeText(this, "Allow both permissions first", Toast.LENGTH_SHORT).show() else s.demo(i)
            }, LinearLayout.LayoutParams(0, WC, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        box.addView(row)

        box.addView(btn("App settings (autostart, battery)") {
            go(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + packageName)))
        }, top(22))
        box.addView(TextView(this).apply {
            text = "Move the sliders until the pill sits exactly over your front camera. " +
                "On Xiaomi/MIUI also enable Autostart and Pop-up windows for this app, " +
                "and set battery saver to No restrictions, otherwise the system may stop the island."
            textSize = 12f; setTextColor(0x99FFFFFF.toInt()); setPadding(0, dp(12), 0, 0)
        })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(0xFF0B0B0F.toInt()); fitsSystemWindows = true; addView(box)
        })
    }

    override fun onResume() {
        super.onResume()
        retries = 0
        refresh()
    }

    private fun mark(tv: TextView, ok: Boolean, text: String) {
        tv.text = (if (ok) "\u2713  " else "\u2717  ") + text
        tv.setTextColor(if (ok) 0xFF30D158.toInt() else 0xFFFF453A.toInt())
    }

    private fun refresh() {
        val ov = Settings.canDrawOverlays(this)
        val ls = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        mark(overlayTv, ov, "Display over other apps")
        mark(listenerTv, ls, "Notification access")
        overlayBtn.visibility = if (ov) View.GONE else View.VISIBLE
        listenerBtn.visibility = if (ls) View.GONE else View.VISIBLE
        val running = IslandService.instance != null
        mark(runTv, running, if (running) "Island is running" else "Island is not running yet")
        if (ls && !running && retries < 4) {
            retries++
            try { NotificationListenerService.requestRebind(ComponentName(this, IslandService::class.java)) } catch (e: Exception) { }
            runTv.postDelayed({ refresh() }, 1200)
        }
    }
}
